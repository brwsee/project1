import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:workmanager/workmanager.dart';
import '../../core/logging/app_logger_service.dart';
import '../../core/security/encryption_service.dart';
import '../sync/sync_upload_service.dart';
import '../../core/sync/hlc_clock.dart';
import '../../data/local/local_database.dart';

/// اسم مهمة التزامن الدورية في الخلفية
const String kBackgroundSyncTaskName = 'skl_periodic_cloud_sync_task';

/// نقطة الدخول لمهام الخلفية في نظام التشغيل (Top-Level Callback)
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    try {
      final encryption = LocalEncryptionService();
      final db = LocalDatabase(encryptionService: encryption);
      final hlc = HybridLogicalClock(nodeId: 'bg-worker-node');
      final syncService = SyncUploadService(
        localDb: db,
        hlcClock: hlc,
        simulateCloudInDemoMode: true,
      );

      await syncService.syncPendingEntries();
      return true;
    } catch (_) {
      return false;
    }
  });
}

/// مراقب الاتصال بالشبكة ومجدول المزامنة الأوتوماتيكية
class AutoSyncConnectivityWatcher {
  final SyncUploadService _syncService;
  final AppLoggerService _logger;
  final void Function()? onSyncCompleted;

  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;
  bool _isAutoSyncRunning = false;
  bool autoSyncEnabled = true;

  AutoSyncConnectivityWatcher({
    required SyncUploadService syncService,
    required AppLoggerService logger,
    this.onSyncCompleted,
  })  : _syncService = syncService,
        _logger = logger;

  /// بدء مراقبة عودة الاتصال بالإنترنت لتشغيل الرفع والتفريغ تلقائياً
  void startWatching() {
    _connectivitySub?.cancel();
    _connectivitySub = Connectivity()
        .onConnectivityChanged
        .listen((List<ConnectivityResult> results) async {
      if (!autoSyncEnabled || _isAutoSyncRunning) return;

      final hasConnection = results.any(
        (r) =>
            r == ConnectivityResult.wifi ||
            r == ConnectivityResult.mobile ||
            r == ConnectivityResult.ethernet,
      );

      if (hasConnection) {
        _isAutoSyncRunning = true;
        try {
          await _logger.log(
            category: 'UPLOAD_TUS',
            message: 'تم رصد اتصال بالإنترنت - بدء المزامنة الأوتوماتيكية.',
          );
          final count = await _syncService.syncPendingEntries();
          if (count > 0 && onSyncCompleted != null) {
            onSyncCompleted!();
          }
        } finally {
          _isAutoSyncRunning = false;
        }
      }
    });
  }

  /// تسجيل مهمة خلفية دورية في نظام التشغيل (Android WorkManager / iOS BGTask)
  static Future<void> initializeBackgroundWorker() async {
    try {
      await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
      await Workmanager().registerPeriodicTask(
        'skl_periodic_sync_id',
        kBackgroundSyncTaskName,
        frequency: const Duration(minutes: 15),
        constraints: Constraints(
          networkType: NetworkType.connected,
        ),
      );
    } catch (_) {
      // في حال التشغيل على بيئة سطح مكتب أو محاكي لا يدعم WorkManager
    }
  }

  Future<void> dispose() async {
    await _connectivitySub?.cancel();
  }
}
