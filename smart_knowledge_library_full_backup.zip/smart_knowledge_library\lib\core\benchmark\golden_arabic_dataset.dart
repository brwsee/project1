import '../utils/arabic_text_evaluator.dart';
import '../../domain/models/knowledge_entry.dart';

/// حالة اختبار واحدة ضمن حزمة الاختبار الذهبية للهجات العربية
class ArabicGoldenBenchmarkCase {
  final String id;
  final ArabicDialect dialect;
  final String environmentDescription; // مثلاً: بيئة هادئة، ضوضاء مقهى، مصطلحات تقنية
  final String referenceTranscript;
  final String simulatedSttOutput;
  final double targetMinAccuracyPercent;

  const ArabicGoldenBenchmarkCase({
    required this.id,
    required this.dialect,
    required this.environmentDescription,
    required this.referenceTranscript,
    required this.simulatedSttOutput,
    this.targetMinAccuracyPercent = 88.0,
  });

  double get measuredAccuracyPercent =>
      ArabicTextEvaluator.calculateAccuracyPercentage(
        referenceTranscript,
        simulatedSttOutput,
      );

  double get measuredNormalizedWer =>
      ArabicTextEvaluator.calculateNormalizedWer(
        referenceTranscript,
        simulatedSttOutput,
      );

  bool get isPassed => measuredAccuracyPercent >= targetMinAccuracyPercent;
}

/// حزمة الاختبار المرجعية (Golden Arabic Dialect Benchmark Suite)
/// لاختبار دقة التفريغ العربي في الفصحى واللهجات المتعددة
class GoldenArabicBenchmarkSuite {
  static const List<ArabicGoldenBenchmarkCase> standardCases = [
    ArabicGoldenBenchmarkCase(
      id: 'msa_01',
      dialect: ArabicDialect.msa,
      environmentDescription: 'فصحى - تلخيص كتاب معرفي (بيئة هادئة)',
      referenceTranscript:
          'تُعَدُّ المَكْتَبَةُ المَعْرِفِيَّةُ الذَّكِيَّةُ أَدَاةً فَعَّالَةً لِحِفْظِ الأفْكَارِ وَتَفْرِيغِهَا بِدِقَّةٍ عَالِيَةٍ.',
      simulatedSttOutput:
          'تعد المكتبه المعرفيه الذكيه اداه فعاله لحفظ الافكار وتفريغها بدقه عاليه',
      targetMinAccuracyPercent: 93.0,
    ),
    ArabicGoldenBenchmarkCase(
      id: 'gulf_01',
      dialect: ArabicDialect.gulf,
      environmentDescription: 'لهجة خليجية - اجتماع عمل سريع',
      referenceTranscript:
          'يا جماعة الخير، نبي نخلص خطة المشروع اليوم ونرفع الملخص على النظام قبل نهاية الدوام.',
      simulatedSttOutput:
          'يا جماعه الخير نبي نخلص خطه المشروع اليوم ونرفع الملخص على النظام قبل نهايه الدوام',
      targetMinAccuracyPercent: 90.0,
    ),
    ArabicGoldenBenchmarkCase(
      id: 'egyptian_01',
      dialect: ArabicDialect.egyptian,
      environmentDescription: 'لهجة مصرية - ملاحظة بحثية صوتية',
      referenceTranscript:
          'الفكرة الأساسية هنا إننا بنسجل الملاحظة في دقيقتين بس، والتطبيق بيرفعها أول ما النت يرجع.',
      simulatedSttOutput:
          'الفكره الاساسيه هنا اننا بنسجل الملاحظه في دقيقتين بس والتطبيق بيرفعها اول ما النت يرجع',
      targetMinAccuracyPercent: 90.0,
    ),
    ArabicGoldenBenchmarkCase(
      id: 'levantine_01',
      dialect: ArabicDialect.levantine,
      environmentDescription: 'لهجة شامية - مراجعة نقاط محاضرة',
      referenceTranscript:
          'هلق رح نحكي عن أهم النقاط يلي مرت معنا بالمحاضرة وكيف نرتبها حسب الوقت.',
      simulatedSttOutput:
          'هلق رح نحكي عن اهم النقاط يلي مرت معنا بالمحاضره وكيف نرتبها حسب الوقت',
      targetMinAccuracyPercent: 88.0,
    ),
    ArabicGoldenBenchmarkCase(
      id: 'maghrebi_01',
      dialect: ArabicDialect.maghrebi,
      environmentDescription: 'لهجة مغاربية - تدوين فكرة تقنية',
      referenceTranscript:
          'هاد التطبيق كيساعد بزاف في تسجيل الأفكار اليومية بلا أنترنت وبجودة عالية.',
      simulatedSttOutput:
          'هاد التطبيق كيساعد بزاف في تسجيل الافكار اليوميه بلا انترنت وبجوده عاليه',
      targetMinAccuracyPercent: 88.0,
    ),
  ];

  /// تشغيل جميع اختبارات اللهجات وإرجاع متوسط الدقة الكلي وحالة النجاح
  static ({
    double averageAccuracyPercent,
    int passedCount,
    int totalCount,
    List<ArabicGoldenBenchmarkCase> results,
  }) runAllBenchmarks() {
    var sumAccuracy = 0.0;
    var passed = 0;

    for (final testCase in standardCases) {
      sumAccuracy += testCase.measuredAccuracyPercent;
      if (testCase.isPassed) passed++;
    }

    final avg = standardCases.isNotEmpty
        ? sumAccuracy / standardCases.length
        : 100.0;

    return (
      averageAccuracyPercent: avg,
      passedCount: passed,
      totalCount: standardCases.length,
      results: standardCases,
    );
  }
}
