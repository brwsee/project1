import 'package:uuid/uuid.dart';
import '../../domain/models/knowledge_entry.dart';
import '../sync/hlc_clock.dart';

/// حالة تعارض بين تعديلين على نفس الفقرة من جهازين مختلفين
class SegmentConflict {
  final TranscriptSegment localSegment;
  final TranscriptSegment remoteSegment;

  const SegmentConflict({
    required this.localSegment,
    required this.remoteSegment,
  });
}

/// محرك حل التعارضات على مستوى الفقرات والكلمات (HLC + Word-Level Merge)
class ConflictResolver {
  final HybridLogicalClock _hlcClock;
  final _uuid = const Uuid();

  ConflictResolver({required HybridLogicalClock hlcClock})
      : _hlcClock = hlcClock;

  /// مقارنة قائمة الفقرات المحلية مع الواردة من جهاز آخر أو من السحابة
  /// وإرجاع الفقرات المدمجة تلقائياً + قائمة التعارضات التي عدّلها المستخدم على الجهازين معاً
  ({
    List<TranscriptSegment> resolvedSegments,
    List<SegmentConflict> manualConflicts,
  }) resolveSegments({
    required List<TranscriptSegment> localSegments,
    required List<TranscriptSegment> remoteSegments,
  }) {
    final remoteByIndex = {
      for (final s in remoteSegments) s.segmentIndex: s,
    };

    final resolved = <TranscriptSegment>[];
    final conflicts = <SegmentConflict>[];

    for (final local in localSegments) {
      final remote = remoteByIndex.remove(local.segmentIndex);
      if (remote == null) {
        resolved.add(local);
        continue;
      }

      // إذا كان النص متطابقاً، نأخذ الأحدث في طابع HLC
      if (local.editedText.trim() == remote.editedText.trim()) {
        resolved.add(
          local.hlcTimestamp.compareTo(remote.hlcTimestamp) >= 0
              ? local
              : remote,
        );
        continue;
      }

      // إذا لم يعدّل المستخدم النسخة المحلية يدوياً، نقبل التحديث السحابي/البعيد فوراً
      if (!local.isUserModified) {
        resolved.add(remote);
        continue;
      }

      // إذا عدّل المستخدم النسخة المحلية فقط ولم تُعدّل النسخة البعيدة يدوياً
      if (local.isUserModified && !remote.isUserModified) {
        resolved.add(local);
        continue;
      }

      // كلا الجهازين قاما بتعديل يدوي مختلف على نفس الفقرة -> نسجل تعارضاً ليختار المستخدم أو يدمجهما
      conflicts.add(
        SegmentConflict(localSegment: local, remoteSegment: remote),
      );
      // نحتفظ مؤقتاً بالنسخة صاحبة طابع HLC الأحدث حتى يبتّ المستخدم
      resolved.add(
        local.hlcTimestamp.compareTo(remote.hlcTimestamp) >= 0
            ? local
            : remote,
      );
    }

    // إضافة أي فقرات جديدة واردة من الطرف البعيد
    for (final remainingRemote in remoteByIndex.values) {
      resolved.add(remainingRemote);
    }

    resolved.sort((a, b) => a.segmentIndex.compareTo(b.segmentIndex));
    return (resolvedSegments: resolved, manualConflicts: conflicts);
  }

  /// دمج نصين متعارضين للفقرة نفسها في فقرة موحدة بدون فقدان أي جملة
  TranscriptSegment mergeBothVersions(SegmentConflict conflict) {
    final mergedText =
        '${conflict.localSegment.editedText.trim()} — ${conflict.remoteSegment.editedText.trim()}';
    return conflict.localSegment.copyWith(
      editedText: mergedText,
      isUserModified: true,
      hlcTimestamp: _hlcClock.now(),
    );
  }

  /// إنشاء تعارض تجريبي لاختبار واجهة فض التعارضات بين الأجهزة في المحرر
  SegmentConflict createSimulatedConflict(TranscriptSegment baseSegment) {
    final remoteHlc = _hlcClock.now();
    final remoteVariant = TranscriptSegment(
      id: _uuid.v4(),
      entryId: baseSegment.entryId,
      segmentIndex: baseSegment.segmentIndex,
      startMs: baseSegment.startMs,
      endMs: baseSegment.endMs,
      rawText: baseSegment.rawText,
      editedText: '${baseSegment.editedText} (تعديل متزامن من جهاز لوحي آخر)',
      isUserModified: true,
      hlcTimestamp: remoteHlc,
    );
    return SegmentConflict(
      localSegment: baseSegment,
      remoteSegment: remoteVariant,
    );
  }
}
