-- =============================================================================
-- المكتبة المعرفية الذكية (Smart Knowledge Library)
-- مخطط قاعدة البيانات المحلية المشفرة (SQLite + SQLCipher + FTS5 + HLC Sync)
-- متوافق مع: lib/data/local/local_database.dart
-- =============================================================================

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- 1. جدول الملاحظات الصوتية المعرفية الرئيسي (مع قيد صارم بحد أقصى 120,000 مللي ثانية = دقيقتين)
CREATE TABLE IF NOT EXISTS knowledge_entries (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    summary TEXT DEFAULT '',
    raw_transcript TEXT NOT NULL,
    corrected_transcript TEXT NOT NULL,
    segments_json TEXT NOT NULL DEFAULT '[]',
    tags_json TEXT NOT NULL DEFAULT '[]',
    dialect TEXT NOT NULL DEFAULT 'msa',
    sync_status TEXT NOT NULL DEFAULT 'localDraft',
    encrypted_audio_path TEXT,
    audio_file_size_bytes INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER NOT NULL CHECK(duration_ms > 0 AND duration_ms <= 120000),
    confidence_score REAL NOT NULL DEFAULT 0.0,
    hlc_timestamp TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    is_audio_evicted INTEGER NOT NULL DEFAULT 0,
    is_deleted INTEGER NOT NULL DEFAULT 0
);

-- 2. جدول فهرسة البحث النصي الفوري (FTS5) مع إزالة التشكيل والهمزات تلقائياً (remove_diacritics 2)
CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(
    entry_id UNINDEXED,
    title,
    corrected_transcript,
    summary,
    tags,
    tokenize = 'unicode61 remove_diacritics 2'
);

-- 3. جدول طابور الرفع المتقطع (Resumable TUS Upload Queue) للعمل بدون إنترنت (Offline-First)
CREATE TABLE IF NOT EXISTS upload_queue (
    entry_id TEXT PRIMARY KEY,
    encrypted_file_path TEXT NOT NULL,
    total_bytes INTEGER NOT NULL,
    uploaded_bytes INTEGER NOT NULL DEFAULT 0,
    upload_session_url TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    next_retry_at TEXT,
    last_error TEXT,
    FOREIGN KEY (entry_id) REFERENCES knowledge_entries(id) ON DELETE CASCADE
);

-- 4. جدول القاموس الشخصي وتصحيحات المستخدم (لتدريب وتحسين دقة نموذج Gemini تلقائياً)
CREATE TABLE IF NOT EXISTS user_custom_vocabulary (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    wrong_word TEXT NOT NULL,
    corrected_word TEXT NOT NULL,
    dialect TEXT NOT NULL DEFAULT 'msa',
    usage_count INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL,
    UNIQUE(wrong_word, corrected_word)
);

-- 5. الفهارس لتسريع الاستعلامات والمزامنة عبر ساعة HLC
CREATE INDEX IF NOT EXISTS idx_entries_sync_status ON knowledge_entries(sync_status);
CREATE INDEX IF NOT EXISTS idx_entries_hlc ON knowledge_entries(hlc_timestamp);
CREATE INDEX IF NOT EXISTS idx_entries_created_at ON knowledge_entries(created_at DESC);
