from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import Principal, current_principal
from ..db import get_db
from ..models import EventLog, Recording, RecordingPart, Segment, Upload, log_event, next_change_seq
from ..pipeline import remove_upload_blob
from ..schemas import ChangesOut, EventOut, RecordingOut, RecordingUpsert, SegmentOut, TranscriptEdit

router = APIRouter(prefix="/v1", tags=["recordings"])


def to_out(rec: Recording, with_segments: bool = True) -> RecordingOut:
    return RecordingOut(
        id=rec.id, title=rec.title, recorded_at=rec.recorded_at, duration_ms=rec.duration_ms, codec=rec.codec,
        latitude=rec.latitude, longitude=rec.longitude, place_name=rec.place_name, dialect_hint=rec.dialect_hint,
        status=rec.status, version=rec.version, change_seq=rec.change_seq, deleted=rec.deleted,
        formatted_text=rec.formatted_text, last_editor_device=rec.last_editor_device,
        segments=[
            SegmentOut(seg_uid=s.seg_uid, idx=s.idx, start_ms=s.start_ms, end_ms=s.end_ms, speaker=s.speaker,
                       text=s.text, original_text=s.original_text, edited=s.edited)
            for s in rec.segments
        ] if with_segments else [],
    )


def _owned(db: Session, rec_id: str, who: Principal) -> Recording:
    rec = db.get(Recording, rec_id)
    if not rec or rec.owner_id != who.user_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "recording not found")
    return rec


@router.put("/recordings/{rec_id}", response_model=RecordingOut)
def upsert_recording(
    rec_id: str, body: RecordingUpsert, who: Principal = Depends(current_principal), db: Session = Depends(get_db)
) -> RecordingOut:
    """تسجيل/تحديث الميتاداتا بشكل idempotent (المعرّف UUID يولده الجهاز دون اتصال)."""
    if body.id != rec_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "id mismatch")
    rec = db.get(Recording, rec_id)
    if rec and rec.owner_id != who.user_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "recording not found")
    if rec and rec.deleted:
        raise HTTPException(status.HTTP_410_GONE, "recording was deleted on another device")
    if not rec:
        rec = Recording(id=rec_id, owner_id=who.user_id, title=body.title, recorded_at=body.recorded_at,
                        last_editor_device=who.device_id)
        db.add(rec)
    rec.duration_ms, rec.codec, rec.sample_rate = body.duration_ms, body.codec, body.sample_rate
    rec.latitude, rec.longitude, rec.place_name = body.latitude, body.longitude, body.place_name
    rec.dialect_hint = body.dialect_hint
    existing = {p.id: p for p in rec.parts}
    for p in body.parts:
        if p.id in existing:
            existing[p.id].duration_ms = p.duration_ms
        else:
            rec.parts.append(RecordingPart(id=p.id, part_index=p.part_index, duration_ms=p.duration_ms))
    db.flush()
    rec.change_seq = next_change_seq(db, who.user_id)
    db.commit()
    db.refresh(rec)
    return to_out(rec)


@router.get("/recordings/{rec_id}", response_model=RecordingOut)
def get_recording(rec_id: str, who: Principal = Depends(current_principal), db: Session = Depends(get_db)):
    return to_out(_owned(db, rec_id, who))


@router.put("/recordings/{rec_id}/transcript", response_model=RecordingOut)
def edit_transcript(
    rec_id: str, body: TranscriptEdit, request: Request,
    who: Principal = Depends(current_principal), db: Session = Depends(get_db),
):
    """تحكم تزامن متفائل: base_version يجب أن يطابق النسخة الحالية، وإلا 409 مع النسخة الخادمة
    ليقوم العميل بدمج ثلاثي (3-way merge) على مستوى الفقرة."""
    rec = _owned(db, rec_id, who)
    if rec.deleted:
        raise HTTPException(status.HTTP_410_GONE, "recording deleted")
    if body.base_version != rec.version:
        request.app.state.metrics.sync_conflicts.inc()
        log_event(db, who.user_id, "conflict", f"base {body.base_version} != server {rec.version}", rec.id)
        db.commit()
        raise HTTPException(status.HTTP_409_CONFLICT, detail={"server": to_out(rec).model_dump(mode="json")})
    by_uid = {s.seg_uid: s for s in rec.segments}
    unknown = [e.seg_uid for e in body.segments if e.seg_uid not in by_uid]
    if unknown:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, detail={"unknown_segments": unknown})
    for e in body.segments:
        seg = by_uid[e.seg_uid]
        seg.text = e.text
        seg.edited = e.text.strip() != seg.original_text.strip()
    if body.title is not None:
        rec.title = body.title
    rec.version += 1
    rec.last_editor_device = who.device_id
    rec.change_seq = next_change_seq(db, who.user_id)
    db.commit()
    db.refresh(rec)
    return to_out(rec)


@router.delete("/recordings/{rec_id}", status_code=204)
def delete_recording(
    rec_id: str, request: Request, who: Principal = Depends(current_principal), db: Session = Depends(get_db)
):
    """حذف نهائي للمحتوى مع إبقاء tombstone لنشر الحذف إلى الأجهزة الأخرى."""
    rec = _owned(db, rec_id, who)
    for up in db.scalars(select(Upload).where(Upload.recording_id == rec.id)):
        remove_upload_blob(request.app.state.settings, up.id)
        up.wrapped_key = ""  # crypto-shredding
    for seg in list(rec.segments):
        db.delete(seg)
    rec.deleted, rec.formatted_text, rec.title = True, None, ""
    rec.latitude = rec.longitude = rec.place_name = None
    rec.version += 1
    rec.change_seq = next_change_seq(db, who.user_id)
    log_event(db, who.user_id, "deleted", "", rec.id)
    db.commit()


@router.get("/sync/changes", response_model=ChangesOut)
def changes(
    since: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=500),
    who: Principal = Depends(current_principal), db: Session = Depends(get_db),
):
    rows = list(db.scalars(
        select(Recording).where(Recording.owner_id == who.user_id, Recording.change_seq > since)
        .order_by(Recording.change_seq).limit(limit + 1)
    ))
    has_more = len(rows) > limit
    rows = rows[:limit]
    cursor = rows[-1].change_seq if rows else since
    return ChangesOut(cursor=cursor, has_more=has_more, recordings=[to_out(r) for r in rows])


@router.get("/events", response_model=list[EventOut])
def events(
    limit: int = Query(100, ge=1, le=1000), recording_id: str | None = None,
    who: Principal = Depends(current_principal), db: Session = Depends(get_db),
):
    q = select(EventLog).where(EventLog.owner_id == who.user_id)
    if recording_id:
        q = q.where(EventLog.recording_id == recording_id)
    return [
        EventOut(id=e.id, recording_id=e.recording_id, kind=e.kind, message=e.message, at=e.at)
        for e in db.scalars(q.order_by(EventLog.id.desc()).limit(limit))
    ]
