"""
خادم «المكتبة المعرفية الذكية» (Smart Knowledge Library Backend API)
يدعم:
1. بروتوكول الرفع المجزأ القابل للاستئناف (TUS Resumable Upload v1.0.0) للمقاطع (≤ دقيقتين).
2. خط التفريغ النصي العربي الفعلي عبر حزمة `google-genai` (Interactions API) باستخدام
   نموذج `gemini-3.8-flash` مع `response_format` مهيكل (Structured Output JSON Schema)
   لدعم اللهجات العربية المتعددة، التدقيق النحوي، والفواصل الزمنية.
3. مزامنة التعديلات وحل التعارضات عبر الساعات المنطقية الهجينة (HLC Delta Sync).
"""

import base64
import os
import uuid
from typing import Dict, List, Optional
from fastapi import FastAPI, Header, HTTPException, Request, Response
from google import genai
from pydantic import BaseModel, Field

app = FastAPI(
    title="Smart Knowledge Library API",
    description="TUS Resumable Upload & Gemini 3.8 Flash Arabic Transcription Pipeline (Max 2 Minutes Audio)",
    version="1.1.0",
)

UPLOAD_STORAGE_DIR = os.path.join(os.path.dirname(__file__), "tus_uploads")
os.makedirs(UPLOAD_STORAGE_DIR, exist_ok=True)


# ============================================================================
# النماذج البيانية (Pydantic Schemas)
# ============================================================================


class TranscribeRequest(BaseModel):
    upload_id: Optional[str] = Field(
        default=None,
        description="معرّف جلسة الرفع TUS إن وجد لتفريغ الملف الفعلي",
    )
    mime_type: str = Field(
        default="audio/ogg",
        description="audio/ogg (Opus) أو audio/wav",
    )
    dialect_hint: str = Field(
        default="auto",
        description="auto | msa | gulf | egyptian | levantine | maghrebi",
    )
    max_duration_sec: int = Field(default=120, le=120)
    enable_grammar_punctuation: bool = True


class SegmentOut(BaseModel):
    segment_index: int = Field(description="الترتيب التسلسلي للفقرة يبدأ من 0")
    start_ms: int = Field(description="بداية الفقرة بالمللي ثانية")
    end_ms: int = Field(description="نهاية الفقرة بالمللي ثانية")
    raw_text: str = Field(description="النص العربي المفرغ كما نُطق")
    punctuated_text: str = Field(
        description="النص العربي بعد التدقيق النحوي وإضافة علامات الترقيم والفواصل"
    )
    confidence: float = Field(default=0.97, description="درجة الثقة من 0.0 إلى 1.0")


class StructuredArabicTranscript(BaseModel):
    dialect_detected: str = Field(description="اللهجة العربية المكتشفة في المقطع")
    segments: List[SegmentOut] = Field(description="قائمة الفقرات المرتبطة بطوابع زمنية")


class TranscribeResponse(BaseModel):
    entry_id: str
    dialect_detected: str
    segments: List[SegmentOut]


class SyncSegmentDelta(BaseModel):
    id: str
    entry_id: str
    segment_index: int
    edited_text: str
    hlc_timestamp: str


class SyncPushRequest(BaseModel):
    device_id: str
    segments: List[SyncSegmentDelta]


# ذاكرة تخزين جلسات الرفع والتزامن
TUS_SESSIONS: Dict[str, dict] = {}
SYNC_DELTAS: Dict[str, SyncSegmentDelta] = {}


# ============================================================================
# 1. نقاط نهاية بروتوكول الرفع المستأنف (TUS Resumable Upload v1.0.0)
# ============================================================================


@app.post("/v1/uploads/tus", status_code=201)
async def create_tus_upload(
    request: Request,
    response: Response,
    upload_length: int = Header(..., alias="Upload-Length"),
    upload_metadata: Optional[str] = Header(default=None, alias="Upload-Metadata"),
):
    # مقطع دقيقتين WAV لا يتجاوز ~4MB، وبصيغة Opus ~480KB
    if upload_length > 6 * 1024 * 1024:
        raise HTTPException(
            status_code=413,
            detail="حجم الملف يتجاوز الحد المسموح به لمقطع الدقيقتين (6MB كحد أقصى).",
        )

    upload_id = str(uuid.uuid4())
    file_path = os.path.join(UPLOAD_STORAGE_DIR, f"{upload_id}.bin")
    with open(file_path, "wb"):
        pass

    TUS_SESSIONS[upload_id] = {
        "upload_id": upload_id,
        "total_length": upload_length,
        "offset": 0,
        "file_path": file_path,
        "metadata": upload_metadata or "",
    }

    base_url = str(request.base_url).rstrip("/")
    response.headers["Location"] = f"{base_url}/v1/uploads/tus/{upload_id}"
    response.headers["Tus-Resumable"] = "1.0.0"
    return {"upload_id": upload_id}


@app.head("/v1/uploads/tus/{upload_id}")
async def get_tus_upload_offset(upload_id: str, response: Response):
    session = TUS_SESSIONS.get(upload_id)
    if not session:
        raise HTTPException(status_code=404, detail="جلسة الرفع غير موجودة.")

    response.headers["Upload-Offset"] = str(session["offset"])
    response.headers["Upload-Length"] = str(session["total_length"])
    response.headers["Tus-Resumable"] = "1.0.0"
    response.headers["Cache-Control"] = "no-store"
    return Response(status_code=200, headers=dict(response.headers))


@app.patch("/v1/uploads/tus/{upload_id}", status_code=204)
async def patch_tus_upload_chunk(
    upload_id: str,
    request: Request,
    response: Response,
    upload_offset: int = Header(..., alias="Upload-Offset"),
):
    session = TUS_SESSIONS.get(upload_id)
    if not session:
        raise HTTPException(status_code=404, detail="جلسة الرفع غير موجودة.")

    if upload_offset != session["offset"]:
        raise HTTPException(
            status_code=409,
            detail=f"تعارض في الـ Offset: المتوقع {session['offset']} والمرسل {upload_offset}",
        )

    chunk = await request.body()
    with open(session["file_path"], "ab") as f:
        f.seek(upload_offset)
        f.write(chunk)

    session["offset"] += len(chunk)
    response.headers["Upload-Offset"] = str(session["offset"])
    response.headers["Tus-Resumable"] = "1.0.0"
    return Response(status_code=204, headers=dict(response.headers))


# ============================================================================
# 2. نقطة نهاية التفريغ النصي العربي عبر Gemini Interactions API (`gemini-3.8-flash`)
# ============================================================================


@app.post("/v1/entries/{entry_id}/transcribe", response_model=TranscribeResponse)
async def transcribe_arabic_audio(entry_id: str, body: TranscribeRequest):
    """
    ينفذ التفريغ الصوتي العربي الدقيق والتدقيق النحوي باستخدام Gemini Interactions API
    (`client.interactions.create` مع `model="gemini-3.8-flash"` و `response_format` مهيكل).
    بما أن المقطع لا يتعدى دقيقتين (≤ 120 ثانية)، يتم تمريره مباشرة كـ Inline Audio Base64.
    """
    dialect_prompts = {
        "msa": "العربية الفصحى المعاصرة مع ضبط الهمزات وعلامات الترقيم.",
        "gulf": "لهجة خليجية عربية مع الحفاظ على المفردات المحلية وضبط الفواصل.",
        "egyptian": "لهجة مصرية عربية مع الحفاظ على السياق وضبط علامات الترقيم.",
        "levantine": "لهجة شامية عربية مع ضبط الفواصل الزمنية.",
        "maghrebi": "لهجة مغاربية عربية واضحة مع الفواصل الزمنية.",
        "auto": "كشف تلقائي للهجة العربية مع تدقيق نحوي وترقيم كامل.",
    }
    dialect_instruction = dialect_prompts.get(body.dialect_hint, dialect_prompts["auto"])

    api_key = os.environ.get("GEMINI_API_KEY")
    session = TUS_SESSIONS.get(body.upload_id) if body.upload_id else None

    if api_key and session and os.path.exists(session["file_path"]):
        with open(session["file_path"], "rb") as f:
            audio_bytes = f.read()

        audio_b64 = base64.b64encode(audio_bytes).decode("utf-8")
        client = genai.Client(api_key=api_key)

        prompt = (
            "قم بتفريغ هذا المقطع الصوتي العربي بدقة عالية وتقسيمه إلى فقرات زمنية متناسقة.\n"
            f"إرشاد اللهجة واللغة: {dialect_instruction}\n"
            "المطلوب لكل فقرة:\n"
            "1. تحديد بداية ونهاية الفقرة بالمللي ثانية (start_ms, end_ms).\n"
            "2. كتابة النص الخام (raw_text) والنص المدقق نحوياً وإملائياً مع الفواصل وعلامات الترقيم العربية (punctuated_text)."
        )

        interaction = client.interactions.create(
            model="gemini-3.8-flash",
            input=[
                {"type": "text", "text": prompt},
                {
                    "type": "audio",
                    "data": audio_b64,
                    "mime_type": body.mime_type,
                },
            ],
            response_format={
                "type": "text",
                "mime_type": "application/json",
                "schema": StructuredArabicTranscript.model_json_schema(),
            },
        )

        parsed = StructuredArabicTranscript.model_validate_json(interaction.output_text)
        return TranscribeResponse(
            entry_id=entry_id,
            dialect_detected=parsed.dialect_detected,
            segments=parsed.segments,
        )

    # استجابة احتياطية عند التشغيل المحلي بدون ملف صوتي مرفوع أو بدون مفتاح GEMINI_API_KEY
    segments = [
        SegmentOut(
            segment_index=0,
            start_ms=0,
            end_ms=14500,
            raw_text="بسم الله الرحمن الرحيم هذه خلاصة معرفية مسجلة عبر المكتبة المعرفية الذكية",
            punctuated_text="بسم الله الرحمن الرحيم، هذه خلاصة معرفية مسجلة عبر «المكتبة المعرفية الذكية».",
            confidence=0.98,
        ),
        SegmentOut(
            segment_index=1,
            start_ms=14500,
            end_ms=32000,
            raw_text="تم رفع المقطع الصوتي وتفريغه بدقة عالية مع دعم اللهجات العربية والفواصل الزمنية",
            punctuated_text="تم رفع المقطع الصوتي وتفريغه بدقة عالية، مع دعم اللهجات العربية والفواصل الزمنية.",
            confidence=0.96,
        ),
    ]

    return TranscribeResponse(
        entry_id=entry_id,
        dialect_detected=body.dialect_hint,
        segments=segments,
    )


# ============================================================================
# 3. نقاط نهاية المزامنة وحل التعارضات عبر الساعات المنطقية الهجينة (HLC Sync)
# ============================================================================


@app.post("/v1/sync/push")
async def push_segment_edits(payload: SyncPushRequest):
    updated_count = 0
    for incoming in payload.segments:
        existing = SYNC_DELTAS.get(incoming.id)
        if existing is None or incoming.hlc_timestamp > existing.hlc_timestamp:
            SYNC_DELTAS[incoming.id] = incoming
            updated_count += 1

    return {"status": "ok", "updated_segments": updated_count}


@app.get("/v1/sync/delta")
async def pull_segment_deltas(since_hlc: str = ""):
    deltas = [
        seg
        for seg in SYNC_DELTAS.values()
        if seg.hlc_timestamp > since_hlc
    ]
    deltas.sort(key=lambda s: s.hlc_timestamp)
    return {"deltas": deltas}
