"""مقاييس جودة التفريغ: WER / CER بمسافة Levenshtein مع تطبيع عربي."""
from __future__ import annotations

from dataclasses import dataclass

from .arabic import normalize_for_matching


@dataclass
class ErrorCounts:
    substitutions: int
    deletions: int
    insertions: int
    ref_len: int

    @property
    def rate(self) -> float:
        if self.ref_len == 0:
            return 0.0 if (self.insertions == 0) else 1.0
        return (self.substitutions + self.deletions + self.insertions) / self.ref_len


def _align(ref: list[str], hyp: list[str]) -> ErrorCounts:
    n, m = len(ref), len(hyp)
    # dp[j] = (cost, S, D, I)
    prev = [(j, 0, 0, j) for j in range(m + 1)]
    for i in range(1, n + 1):
        cur = [(i, 0, i, 0)] + [(0, 0, 0, 0)] * m
        for j in range(1, m + 1):
            if ref[i - 1] == hyp[j - 1]:
                cur[j] = prev[j - 1]
                continue
            sub = prev[j - 1]
            dele = prev[j]
            ins = cur[j - 1]
            best = min(
                (sub[0] + 1, sub[1] + 1, sub[2], sub[3]),
                (dele[0] + 1, dele[1], dele[2] + 1, dele[3]),
                (ins[0] + 1, ins[1], ins[2], ins[3] + 1),
                key=lambda t: t[0],
            )
            cur[j] = best
        prev = cur
    _, s, d, ins_ = prev[m]
    return ErrorCounts(s, d, ins_, n)


def wer(reference: str, hypothesis: str, normalize: bool = True) -> ErrorCounts:
    if normalize:
        reference, hypothesis = normalize_for_matching(reference), normalize_for_matching(hypothesis)
    return _align(reference.split(), hypothesis.split())


def cer(reference: str, hypothesis: str, normalize: bool = True) -> ErrorCounts:
    if normalize:
        reference, hypothesis = normalize_for_matching(reference), normalize_for_matching(hypothesis)
    return _align(list(reference.replace(" ", "")), list(hypothesis.replace(" ", "")))
