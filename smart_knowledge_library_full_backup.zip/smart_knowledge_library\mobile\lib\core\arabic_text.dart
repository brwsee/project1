/// تطبيع النص العربي للبحث المحلي — مرآة لـ backend/app/arabic.py (normalize_for_matching).
library;

final _diacritics = RegExp(r'[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]');
final _alef = RegExp(r'[\u0622\u0623\u0625\u0671]');
final _punct = RegExp(r'[^\p{L}\p{N}\s]', unicode: true);
final _spaces = RegExp(r'\s+');
const _arabicIndic = '٠١٢٣٤٥٦٧٨٩';
const _persianIndic = '۰۱۲۳۴۵۶۷۸۹';

String normalizeArabic(String input) {
  final sb = StringBuffer();
  for (final rune in input.runes) {
    final ch = String.fromCharCode(rune);
    var i = _arabicIndic.indexOf(ch);
    if (i < 0) i = _persianIndic.indexOf(ch);
    sb.write(i >= 0 ? '$i' : ch);
  }
  var t = sb.toString();
  t = t.replaceAll(_diacritics, '');
  t = t.replaceAll(_alef, 'ا');
  t = t.replaceAll('ة', 'ه').replaceAll('ى', 'ي').replaceAll('ؤ', 'ء').replaceAll('ئ', 'ء');
  t = t.replaceAll(_punct, ' ');
  return t.replaceAll(_spaces, ' ').trim().toLowerCase();
}

/// يبني استعلام FTS آمناً: كل كلمة كبادئة، مع إزالة الرموز الخاصة بـ FTS.
String buildFtsQuery(String userQuery) {
  final words = normalizeArabic(userQuery).split(' ').where((w) => w.isNotEmpty);
  return words.map((w) => '${w.replaceAll('"', '')}*').join(' ');
}

String formatTimestamp(int ms) {
  final d = Duration(milliseconds: ms);
  final h = d.inHours;
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:$m:$s' : '$m:$s';
}
