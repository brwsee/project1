import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart' as crypto;
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// خدمة التشفير المحلي للملفات الصوتية (الحد الأقصى دقيقتان ~480KB Opus / 3.8MB WAV)
/// تعمل بالكامل في الذاكرة (In-Memory AES-256-GCM) في أقل من 15ms
class LocalEncryptionService {
  static const _masterKeyAlias = 'skl_master_aes256_key_v1';
  static const _dbPassphraseAlias = 'skl_sqlcipher_passphrase_v1';

  final FlutterSecureStorage _secureStorage;
  final AesGcm _cipher = AesGcm.with256bits();

  LocalEncryptionService({FlutterSecureStorage? secureStorage})
      : _secureStorage = secureStorage ??
            const FlutterSecureStorage(
              aOptions: AndroidOptions(encryptedSharedPreferences: true),
            );

  /// الحصول على كلمة مرور تشفير قاعدة البيانات SQLCipher أو إنشاؤها
  Future<String> getOrCreateDatabasePassphrase() async {
    var passphrase = await _secureStorage.read(key: _dbPassphraseAlias);
    if (passphrase == null) {
      final randomKey = await _cipher.newSecretKey();
      final bytes = await randomKey.extractBytes();
      passphrase = base64UrlEncode(bytes);
      await _secureStorage.write(key: _dbPassphraseAlias, value: passphrase);
    }
    return passphrase;
  }

  /// الحصول على مفتاح التشفير الرئيسي AES-256 أو توليده في شريحة الأمان
  Future<SecretKey> _getOrCreateMasterKey() async {
    final storedBase64 = await _secureStorage.read(key: _masterKeyAlias);
    if (storedBase64 != null) {
      return SecretKey(base64Decode(storedBase64));
    }
    final newKey = await _cipher.newSecretKey();
    final keyBytes = await newKey.extractBytes();
    await _secureStorage.write(
      key: _masterKeyAlias,
      value: base64Encode(keyBytes),
    );
    return newKey;
  }

  /// تشفير ملف صوتي محلياً وحذف النسخة غير المشفرة فوراً
  Future<({String encryptedFilePath, String ivBase64, String sha256Hex, int sizeBytes})>
      encryptAudioFile(File sourceFile, {bool deleteOriginal = true}) async {
    final clearBytes = await sourceFile.readAsBytes();
    final secretKey = await _getOrCreateMasterKey();
    final nonce = _cipher.newNonce();

    final secretBox = await _cipher.encrypt(
      clearBytes,
      secretKey: secretKey,
      nonce: nonce,
    );

    // دمج CipherText + MAC (16 bytes) في ملف مشفر واحد
    final combinedBytes = BytesBuilder(copy: false)
      ..add(secretBox.cipherText)
      ..add(secretBox.mac.bytes);

    final encryptedBytes = combinedBytes.toBytes();
    final sha256Digest = crypto.sha256.convert(encryptedBytes).toString();

    final encryptedFilePath = '${sourceFile.path}.enc';
    final encryptedFile = File(encryptedFilePath);
    await encryptedFile.writeAsBytes(encryptedBytes, flush: true);

    if (deleteOriginal && await sourceFile.exists()) {
      await sourceFile.delete();
    }

    return (
      encryptedFilePath: encryptedFilePath,
      ivBase64: base64Encode(nonce),
      sha256Hex: sha256Digest,
      sizeBytes: encryptedBytes.length,
    );
  }

  /// فك تشفير ملف صوتي في الذاكرة المؤقتة للتشغيل المحلي أو الرفع الآمن
  Future<Uint8List> decryptAudioFile({
    required File encryptedFile,
    required String ivBase64,
  }) async {
    final encryptedBytes = await encryptedFile.readAsBytes();
    final secretKey = await _getOrCreateMasterKey();
    final nonce = base64Decode(ivBase64);

    const macLength = 16;
    if (encryptedBytes.length < macLength) {
      throw const FormatException('ملف صوتي مشفر غير صالح أو تالف.');
    }

    final cipherText = encryptedBytes.sublist(
      0,
      encryptedBytes.length - macLength,
    );
    final macBytes = encryptedBytes.sublist(encryptedBytes.length - macLength);

    final secretBox = SecretBox(
      cipherText,
      nonce: nonce,
      mac: Mac(macBytes),
    );

    final clearBytes = await _cipher.decrypt(
      secretBox,
      secretKey: secretKey,
    );

    return Uint8List.fromList(clearBytes);
  }
}
