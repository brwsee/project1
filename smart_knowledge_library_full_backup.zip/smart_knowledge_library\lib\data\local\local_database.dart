import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../core/security/encryption_service.dart';
import '../../domain/models/knowledge_entry.dart';

/// قاعدة البيانات المحلية المشفرة (SQLite + SQLCipher + FTS5)
class LocalDatabase {
  static const _dbName = 'smart_knowledge_library.db';
  static const _dbVersion = 1;

  final LocalEncryptionService _encryptionService;
  Database? _db;

  LocalDatabase({required LocalEncryptionService encryptionService})
      : _encryptionService = encryptionService;

  Future<Database> get database async {
    if (_db != null && _db!.isOpen) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  Future<Database> _initDatabase() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(docsDir.path, _dbName);
    final passphrase = await _encryptionService.getOrCreateDatabasePassphrase();

    return openDatabase(
      dbPath,
      password: passphrase,
      version: _dbVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (db, version) async {
        // 1. جدول الكيانات المعرفية (التسجيلات الصوتية ≤ 120 ثانية + الميتا)
        await db.execute('''
          CREATE TABLE knowledge_entries (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            recorded_at INTEGER NOT NULL,
            duration_ms INTEGER NOT NULL CHECK(duration_ms <= 120000),
            audio_format TEXT DEFAULT 'opus',
            sample_rate INTEGER DEFAULT 16000,
            local_file_path TEXT,
            file_size_bytes INTEGER NOT NULL,
            file_sha256 TEXT NOT NULL,
            encryption_iv TEXT NOT NULL,
            latitude REAL,
            longitude REAL,
            place_name TEXT,
            dialect_hint TEXT DEFAULT 'auto',
            sync_status TEXT DEFAULT 'LOCAL_ONLY',
            hlc_timestamp TEXT NOT NULL,
            version INTEGER DEFAULT 1,
            is_deleted INTEGER DEFAULT 0,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
          )
        ''');

        // 2. جدول الفقرات النصية والطوابع الزمنية
        await db.execute('''
          CREATE TABLE transcript_segments (
            id TEXT PRIMARY KEY,
            entry_id TEXT NOT NULL REFERENCES knowledge_entries(id) ON DELETE CASCADE,
            segment_index INTEGER NOT NULL,
            start_ms INTEGER NOT NULL,
            end_ms INTEGER NOT NULL,
            raw_text TEXT NOT NULL,
            edited_text TEXT NOT NULL,
            confidence REAL DEFAULT 1.0,
            speaker_tag TEXT,
            is_user_modified INTEGER DEFAULT 0,
            hlc_timestamp TEXT NOT NULL
          )
        ''');

        await db.execute(
          'CREATE INDEX idx_segments_entry ON transcript_segments(entry_id, segment_index)',
        );

        // 3. جدول البحث النصي الكامل (FTS5) مع تجاهل التشكيل العربي
        await db.execute('''
          CREATE VIRTUAL TABLE entries_fts USING fts5(
            entry_id UNINDEXED,
            title,
            content,
            tokenize = 'unicode61 remove_diacritics 2'
          )
        ''');

        // 4. جدول طابور الرفع وسجل المحاولات والفشل
        await db.execute('''
          CREATE TABLE upload_queue (
            entry_id TEXT PRIMARY KEY REFERENCES knowledge_entries(id) ON DELETE CASCADE,
            tus_upload_url TEXT,
            bytes_uploaded INTEGER DEFAULT 0,
            total_bytes INTEGER NOT NULL,
            retry_count INTEGER DEFAULT 0,
            next_retry_at INTEGER,
            last_error_code TEXT,
            last_error_message TEXT,
            updated_at INTEGER NOT NULL
          )
        ''');
      },
    );
  }

  /// حفظ كيان معرفي جديد وإضافته فوراً إلى طابور الرفع وفهرس البحث
  Future<void> insertEntry(KnowledgeEntry entry) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.insert(
        'knowledge_entries',
        entry.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );

      for (final seg in entry.segments) {
        await txn.insert(
          'transcript_segments',
          seg.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }

      // تحديث فهرس البحث FTS5
      await _updateFtsIndex(txn, entry);

      // إدراج في طابور الرفع التلقائي
      final queueItem = UploadQueueItem(
        entryId: entry.id,
        totalBytes: entry.fileSizeBytes,
        updatedAt: DateTime.now(),
      );
      await txn.insert(
        'upload_queue',
        queueItem.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    });
  }

  /// تحديث فقرة نصية معدلة من قِبل المستخدم مع حماية التعديل عبر HLC
  Future<void> updateSegmentText({
    required String entryId,
    required String segmentId,
    required String newText,
    required String hlcTimestamp,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update(
        'transcript_segments',
        {
          'edited_text': newText,
          'is_user_modified': 1,
          'hlc_timestamp': hlcTimestamp,
        },
        where: 'id = ?',
        whereArgs: [segmentId],
      );

      await txn.update(
        'knowledge_entries',
        {
          'hlc_timestamp': hlcTimestamp,
          'updated_at': DateTime.now().millisecondsSinceEpoch,
        },
        where: 'id = ?',
        whereArgs: [entryId],
      );

      final updatedEntry = await _getEntryByIdTxn(txn, entryId);
      if (updatedEntry != null) {
        await _updateFtsIndex(txn, updatedEntry);
      }
    });
  }

  /// دمج التفريغ السحابي الوارد مع الحفاظ على الفقرات التي عدّلها المستخدم محلياً
  Future<void> mergeCloudTranscript({
    required String entryId,
    required List<TranscriptSegment> cloudSegments,
    required String remoteHlc,
  }) async {
    final db = await database;
    await db.transaction((txn) async {
      final existingRows = await txn.query(
        'transcript_segments',
        where: 'entry_id = ?',
        whereArgs: [entryId],
      );

      final userModifiedByIndex = <int, TranscriptSegment>{};
      for (final row in existingRows) {
        final seg = TranscriptSegment.fromMap(row);
        if (seg.isUserModified) {
          userModifiedByIndex[seg.segmentIndex] = seg;
        }
      }

      await txn.delete(
        'transcript_segments',
        where: 'entry_id = ?',
        whereArgs: [entryId],
      );

      for (final cloudSeg in cloudSegments) {
        final localUserSeg = userModifiedByIndex[cloudSeg.segmentIndex];
        final mergedSeg = localUserSeg != null
            ? cloudSeg.copyWith(
                editedText: localUserSeg.editedText,
                isUserModified: true,
                hlcTimestamp: localUserSeg.hlcTimestamp,
              )
            : cloudSeg;

        await txn.insert('transcript_segments', mergedSeg.toMap());
      }

      await txn.update(
        'knowledge_entries',
        {
          'sync_status': SyncStatus.synced.code,
          'hlc_timestamp': remoteHlc,
          'updated_at': DateTime.now().millisecondsSinceEpoch,
        },
        where: 'id = ?',
        whereArgs: [entryId],
      );

      await txn.delete(
        'upload_queue',
        where: 'entry_id = ?',
        whereArgs: [entryId],
      );

      final updatedEntry = await _getEntryByIdTxn(txn, entryId);
      if (updatedEntry != null) {
        await _updateFtsIndex(txn, updatedEntry);
      }
    });
  }

  /// البحث الفوري في العناوين والنصوص المفرّغة (يدعم العربية بدون تشكيل)
  Future<List<KnowledgeEntry>> searchEntries(String query) async {
    final db = await database;
    if (query.trim().isEmpty) {
      return getAllEntries();
    }

    final sanitized = query.trim().replaceAll('"', '');
    final ftsRows = await db.rawQuery(
      '''
      SELECT entry_id FROM entries_fts
      WHERE entries_fts MATCH ?
      ORDER BY rank
      ''',
      ['"$sanitized"*'],
    );

    final results = <KnowledgeEntry>[];
    for (final row in ftsRows) {
      final id = row['entry_id'] as String;
      final entry = await getEntryById(id);
      if (entry != null && !entry.isDeleted) {
        results.add(entry);
      }
    }
    return results;
  }

  /// جلب جميع التسجيلات مرتبة من الأحدث إلى الأقدم
  Future<List<KnowledgeEntry>> getAllEntries() async {
    final db = await database;
    final rows = await db.query(
      'knowledge_entries',
      where: 'is_deleted = 0',
      orderBy: 'recorded_at DESC',
    );

    final entries = <KnowledgeEntry>[];
    for (final row in rows) {
      final id = row['id'] as String;
      final segRows = await db.query(
        'transcript_segments',
        where: 'entry_id = ?',
        whereArgs: [id],
        orderBy: 'segment_index ASC',
      );
      final segments = segRows.map(TranscriptSegment.fromMap).toList();
      entries.add(KnowledgeEntry.fromMap(row, segments: segments));
    }
    return entries;
  }

  Future<KnowledgeEntry?> getEntryById(String id) async {
    final db = await database;
    return _getEntryByIdTxn(db, id);
  }

  Future<KnowledgeEntry?> _getEntryByIdTxn(
    DatabaseExecutor txn,
    String id,
  ) async {
    final rows = await txn.query(
      'knowledge_entries',
      where: 'id = ?',
      whereArgs: [id],
      limit: 1,
    );
    if (rows.isEmpty) return null;

    final segRows = await txn.query(
      'transcript_segments',
      where: 'entry_id = ?',
      whereArgs: [id],
      orderBy: 'segment_index ASC',
    );
    final segments = segRows.map(TranscriptSegment.fromMap).toList();
    return KnowledgeEntry.fromMap(rows.first, segments: segments);
  }

  Future<void> _updateFtsIndex(
    DatabaseExecutor txn,
    KnowledgeEntry entry,
  ) async {
    await txn.delete(
      'entries_fts',
      where: 'entry_id = ?',
      whereArgs: [entry.id],
    );
    await txn.insert('entries_fts', {
      'entry_id': entry.id,
      'title': entry.title,
      'content': entry.fullTranscriptText,
    });
  }

  /// جلب عناصر طابور الرفع المعلقة أو التي فشلت وحان وقت إعادة محاولتها
  Future<List<UploadQueueItem>> getPendingUploads() async {
    final db = await database;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    final rows = await db.query(
      'upload_queue',
      where: 'next_retry_at IS NULL OR next_retry_at <= ?',
      whereArgs: [nowMs],
      orderBy: 'updated_at ASC',
    );
    return rows.map(UploadQueueItem.fromMap).toList();
  }

  /// تحديث تقدم الرفع أو تسجيل سبب الفشل في السجل المحلي
  Future<void> updateUploadProgress(UploadQueueItem item, SyncStatus status) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.update(
        'upload_queue',
        item.toMap(),
        where: 'entry_id = ?',
        whereArgs: [item.entryId],
      );
      await txn.update(
        'knowledge_entries',
        {
          'sync_status': status.code,
          'updated_at': DateTime.now().millisecondsSinceEpoch,
        },
        where: 'id = ?',
        whereArgs: [item.entryId],
      );
    });
  }

  /// جلب جميع عناصر طابور الرفع (للعرض في شاشة سجل التحميلات والفشل)
  Future<List<UploadQueueItem>> getAllUploadQueueItems() async {
    final db = await database;
    final rows = await db.query(
      'upload_queue',
      orderBy: 'updated_at DESC',
    );
    return rows.map(UploadQueueItem.fromMap).toList();
  }

  /// إزالة مسار الملف الصوتي المحلي بعد إخلاء المساحة الذكي (مع بقاء النص والبيانات)
  Future<void> clearLocalAudioPath(String entryId) async {
    final db = await database;
    await db.update(
      'knowledge_entries',
      {
        'local_file_path': null,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [entryId],
    );
  }
}
