/// الثوابت الهندسية لتطبيق «المكتبة المعرفية الذكية»
class AppConstants {
  AppConstants._();

  /// الحد الأقصى لمدة المقطع الصوتي: دقيقتان (120 ثانية)
  static const int maxRecordingDurationSeconds = 120;
  static const Duration maxRecordingDuration = Duration(seconds: 120);

  /// وقت التنبيه قبل انتهاء المدة القصوى (عند تبقّي 15 ثانية)
  static const int warningThresholdSeconds = 105;

  /// إعدادات الصوت القياسية لتحقيق أفضل دقة تفريغ عربي بأقل حجم
  /// Opus 32kbps @ 16kHz Mono => ~480 KB لكل دقيقتين
  static const int audioSampleRate = 16000;
  static const int opusBitRate = 32000;
  static const int audioChannels = 1; // Mono

  /// حجم الجزء في حال تفعيل الرفع المستأنف على الشبكات الضعيفة (256 KB)
  static const int uploadChunkSizeBytes = 256 * 1024;

  /// الحد الافتراضي للتخزين المحلي الصوتي (500 MB تكفي لأكثر من 1,000 تسجيل بصيغة Opus)
  static const int defaultMaxStorageBytes = 500 * 1024 * 1024;
}
