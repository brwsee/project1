import 'dart:io';
import '../../core/constants/app_constants.dart';
import '../../core/logging/app_logger_service.dart';
import '../../data/local/local_database.dart';
import '../../domain/models/knowledge_entry.dart';

/// إحصائيات استخدام التخزين المحلي
class StorageUsageSummary {
  final int usedBytes;
  final int maxAllowedBytes;
  final int totalEntriesCount;
  final int localAudioFilesCount;
  final int evictableSyncedAudioBytes;

  const StorageUsageSummary({
    required this.usedBytes,
    required this.maxAllowedBytes,
    required this.totalEntriesCount,
    required this.localAudioFilesCount,
    required this.evictableSyncedAudioBytes,
  });

  double get usageRatio =>
      maxAllowedBytes > 0 ? (usedBytes / maxAllowedBytes).clamp(0.0, 1.0) : 0.0;

  String get formattedUsedMb =>
      (usedBytes / (1024 * 1024)).toStringAsFixed(2);

  String get formattedMaxMb =>
      (maxAllowedBytes / (1024 * 1024)).toStringAsFixed(0);

  String get formattedEvictableMb =>
      (evictableSyncedAudioBytes / (1024 * 1024)).toStringAsFixed(2);
}

/// خدمة إدارة حدود التخزين المحلي والإخلاء الذكي للملفات الصوتية المتزامنة
class StorageQuotaService {
  final LocalDatabase _localDb;
  final AppLoggerService _logger;
  int _maxAllowedBytes;

  StorageQuotaService({
    required LocalDatabase localDb,
    required AppLoggerService logger,
    int maxAllowedBytes = AppConstants.defaultMaxStorageBytes,
  })  : _localDb = localDb,
        _logger = logger,
        _maxAllowedBytes = maxAllowedBytes;

  int get maxAllowedBytes => _maxAllowedBytes;

  void setMaxAllowedBytes(int bytes) {
    _maxAllowedBytes = bytes.clamp(50 * 1024 * 1024, 5 * 1024 * 1024 * 1024);
  }

  /// حساب ملخص استهلاك التخزين الحالي
  Future<StorageUsageSummary> calculateUsage() async {
    final entries = await _localDb.getAllEntries();
    var usedBytes = 0;
    var localFilesCount = 0;
    var evictableBytes = 0;

    for (final entry in entries) {
      if (entry.localFilePath != null) {
        final file = File(entry.localFilePath!);
        if (await file.exists()) {
          final len = await file.length();
          usedBytes += len;
          localFilesCount++;
          if (entry.syncStatus == SyncStatus.synced) {
            evictableBytes += len;
          }
        }
      }
    }

    return StorageUsageSummary(
      usedBytes: usedBytes,
      maxAllowedBytes: _maxAllowedBytes,
      totalEntriesCount: entries.length,
      localAudioFilesCount: localFilesCount,
      evictableSyncedAudioBytes: evictableBytes,
    );
  }

  /// إخلاء ذكي للمساحة (Smart Cache Eviction):
  /// يحذف فقط الملفات الصوتية المحلية للتسجيلات القديمة التي تم رفعها وتفريغها بنجاح (SYNCED)
  /// مع الإبقاء الكامل على النصوص المفرّغة والطوابع الزمنية محلياً للبحث والنسخ
  Future<int> enforceQuotaOrEvictSyncedAudio({bool forceEvictAllSynced = false}) async {
    final entries = await _localDb.getAllEntries();
    final summary = await calculateUsage();

    if (!forceEvictAllSynced && summary.usedBytes <= _maxAllowedBytes) {
      return 0;
    }

    // ترتيب من الأقدم إلى الأحدث لإخلاء التسجيلات الأقدم أولاً
    final oldestFirst = entries.reversed.toList();
    var currentUsed = summary.usedBytes;
    var freedBytes = 0;

    for (final entry in oldestFirst) {
      if (!forceEvictAllSynced && currentUsed <= _maxAllowedBytes) break;

      if (entry.syncStatus == SyncStatus.synced && entry.localFilePath != null) {
        final file = File(entry.localFilePath!);
        if (await file.exists()) {
          final fileLen = await file.length();
          await file.delete();
          await _localDb.clearLocalAudioPath(entry.id);
          currentUsed -= fileLen;
          freedBytes += fileLen;
        }
      }
    }

    if (freedBytes > 0) {
      await _logger.log(
        category: 'STORAGE',
        message: 'تم إخلاء مساحة صوتية متزامنة بنجاح مع الاحتفاظ بالنصوص محلياً.',
        metrics: {'freed_bytes': freedBytes},
      );
    }

    return freedBytes;
  }
}
