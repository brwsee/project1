import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// سجل JSON Lines محلي مع تدوير يومي وحد حجم. سياسة: لا تُسجَّل نصوص مفرّغة أو صوت أو
/// رموز مصادقة — فقط أحداث ومعرفات وأرقام أداء.
class AppLogger {
  AppLogger._();
  static final AppLogger instance = AppLogger._();

  static const _maxBytes = 5 * 1024 * 1024;
  static const _keepDays = 7;
  Directory? _dir;
  IOSink? _sink;
  String? _day;

  Future<void> init() async {
    final docs = await getApplicationDocumentsDirectory();
    _dir = Directory(p.join(docs.path, 'logs'))..createSync(recursive: true);
    _purgeOld();
  }

  Directory? get directory => _dir;

  void info(String event, [Map<String, Object?> data = const {}]) => _write('INFO', event, data);
  void warn(String event, [Map<String, Object?> data = const {}]) => _write('WARN', event, data);
  void error(String event, Object err, [StackTrace? st, Map<String, Object?> data = const {}]) =>
      _write('ERROR', event, {...data, 'error': err.toString(), if (st != null) 'stack': st.toString()});

  void _write(String level, String event, Map<String, Object?> data) {
    final dir = _dir;
    if (dir == null) return;
    final now = DateTime.now().toUtc();
    final day = now.toIso8601String().substring(0, 10);
    final file = File(p.join(dir.path, 'app-$day.log'));
    if (_day != day || (file.existsSync() && file.lengthSync() > _maxBytes)) {
      _sink?.close();
      final target = file.existsSync() && file.lengthSync() > _maxBytes
          ? File(p.join(dir.path, 'app-$day-${now.millisecondsSinceEpoch}.log'))
          : file;
      _sink = target.openWrite(mode: FileMode.append);
      _day = day;
    }
    _sink!.writeln(jsonEncode({'ts': now.toIso8601String(), 'level': level, 'event': event, ...data}));
  }

  void _purgeOld() {
    final cutoff = DateTime.now().subtract(const Duration(days: _keepDays));
    for (final f in _dir!.listSync().whereType<File>()) {
      if (f.statSync().modified.isBefore(cutoff)) f.deleteSync();
    }
  }

  Future<void> flush() async => _sink?.flush();
}

final appLog = AppLogger.instance;
