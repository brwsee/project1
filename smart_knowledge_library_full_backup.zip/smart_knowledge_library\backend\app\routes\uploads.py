"""رفع قابل للاستئناف متوافق مع مجموعة فرعية من بروتوكول tus 1.0.0 (core + checksum + termination).

لماذا tus؟ بروتوكول مفتوح وموثّق، توجد له عملاء جاهزة، ويحل مشكلة الشبكات المتقطعة:
العميل يسأل HEAD عن الإزاحة المؤكدة ثم يكمل PATCH منها.
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import Principal, current_principal
from ..db import get_db
from ..models import Recording, RecordingPart, Upload, log_event, next_change_seq, utcnow

router = APIRouter(prefix="/v1/uploads", tags=["uploads"])
TUS_VERSION = "1.0.0"
_locks: dict[str, asyncio.Lock] = {}


def _tus_headers(extra: dict | None = None) -> dict:
    h = {"Tus-Resumable": TUS_VERSION, "Cache-Control": "no-store"}
    h.update(extra or {})
    return h


def _parse_metadata(raw: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for pair in filter(None, (p.strip() for p in raw.split(","))):
        key, _, val = pair.partition(" ")
        try:
            out[key] = base64.b64decode(val).decode() if val else ""
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status.HTTP_400_BAD_REQUEST, f"bad metadata value for {key}") from exc
    return out


def _get_owned(db: Session, upload_id: str, who: Principal) -> Upload:
    up = db.get(Upload, upload_id)
    if not up or up.owner_id != who.user_id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "upload not found")
    if up.status == "in_progress" and up.expires_at < utcnow():
        raise HTTPException(status.HTTP_410_GONE, "upload expired")
    return up


@router.options("")
def options() -> Response:
    return Response(status_code=204, headers=_tus_headers(
        {"Tus-Version": TUS_VERSION, "Tus-Extension": "creation,checksum,termination", "Tus-Checksum-Algorithm": "sha256"}
    ))


@router.post("", status_code=201)
def create_upload(
    request: Request,
    upload_length: int = Header(..., alias="Upload-Length"),
    upload_metadata: str = Header(..., alias="Upload-Metadata"),
    who: Principal = Depends(current_principal),
    db: Session = Depends(get_db),
) -> Response:
    settings = request.app.state.settings
    if upload_length <= 0 or upload_length > settings.max_upload_bytes:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "invalid Upload-Length")
    meta = _parse_metadata(upload_metadata)
    required = {"recording_id", "part_id", "sha256", "key_id", "wrapped_key", "codec"}
    if missing := required - meta.keys():
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"missing metadata: {sorted(missing)}")

    rec = db.get(Recording, meta["recording_id"])
    part = db.get(RecordingPart, meta["part_id"])
    if not rec or rec.owner_id != who.user_id or rec.deleted or not part or part.recording_id != rec.id:
        raise HTTPException(status.HTTP_409_CONFLICT, "register recording metadata first (PUT /v1/recordings/{id})")

    # Idempotency: نفس الجزء ونفس المحتوى => أعد نفس الجلسة لاستئنافها
    existing = db.scalar(
        select(Upload).where(Upload.part_id == part.id, Upload.sha256 == meta["sha256"], Upload.status != "failed")
    )
    if existing:
        return Response(status_code=200, headers=_tus_headers(
            {"Location": f"/v1/uploads/{existing.id}", "Upload-Offset": str(existing.offset)}
        ))

    up = Upload(
        id=str(uuid.uuid4()), owner_id=who.user_id, recording_id=rec.id, part_id=part.id, length=upload_length,
        sha256=meta["sha256"].lower(), key_id=meta["key_id"], wrapped_key=meta["wrapped_key"], codec=meta["codec"],
        expires_at=utcnow() + timedelta(hours=settings.upload_ttl_hours),
    )
    db.add(up)
    (settings.uploads_dir / f"{up.id}.bin").touch()
    rec.status = "uploading"
    log_event(db, who.user_id, "upload_started", f"part {part.part_index}, {upload_length} bytes", rec.id)
    db.commit()
    return Response(status_code=201, headers=_tus_headers({"Location": f"/v1/uploads/{up.id}", "Upload-Offset": "0"}))


@router.head("/{upload_id}")
def head_upload(upload_id: str, who: Principal = Depends(current_principal), db: Session = Depends(get_db)) -> Response:
    up = _get_owned(db, upload_id, who)
    return Response(status_code=200, headers=_tus_headers(
        {"Upload-Offset": str(up.offset), "Upload-Length": str(up.length), "X-Upload-Status": up.status}
    ))


@router.patch("/{upload_id}")
async def patch_upload(
    upload_id: str,
    request: Request,
    upload_offset: int = Header(..., alias="Upload-Offset"),
    content_type: str = Header(..., alias="Content-Type"),
    upload_checksum: str | None = Header(None, alias="Upload-Checksum"),
    who: Principal = Depends(current_principal),
    db: Session = Depends(get_db),
) -> Response:
    settings = request.app.state.settings
    if content_type != "application/offset+octet-stream":
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "use application/offset+octet-stream")
    lock = _locks.setdefault(upload_id, asyncio.Lock())
    async with lock:
        up = _get_owned(db, upload_id, who)
        if up.status == "complete":
            return Response(status_code=204, headers=_tus_headers({"Upload-Offset": str(up.offset)}))
        if up.status == "failed":
            raise HTTPException(status.HTTP_410_GONE, "upload failed; create a new one")
        if upload_offset != up.offset:
            raise HTTPException(status.HTTP_409_CONFLICT, detail={"expected_offset": up.offset})

        body = await request.body()
        if len(body) > settings.max_chunk_bytes:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "chunk too large")
        if up.offset + len(body) > up.length:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "chunk exceeds Upload-Length")
        if upload_checksum:
            algo, _, digest = upload_checksum.partition(" ")
            if algo != "sha256":
                raise HTTPException(status.HTTP_400_BAD_REQUEST, "unsupported checksum algorithm")
            if base64.b64encode(hashlib.sha256(body).digest()).decode() != digest:
                # 460 Checksum Mismatch (tus checksum extension)
                return Response(status_code=460, headers=_tus_headers())

        path = settings.uploads_dir / f"{up.id}.bin"
        with open(path, "r+b") as f:
            f.seek(up.offset)
            f.write(body)
            f.truncate()  # يزيل أي بقايا كتابة جزئية سابقة لم تُؤكَّد
        up.offset += len(body)
        request.app.state.metrics.upload_bytes.inc(len(body))

        if up.offset == up.length:
            _finalize(request, db, up)
        db.commit()
        if up.status == "complete" and settings.worker_inline:
            request.app.state.pipeline.process(request.state.job_id)
        return Response(status_code=204, headers=_tus_headers({"Upload-Offset": str(up.offset)}))


def _finalize(request: Request, db: Session, up: Upload) -> None:
    settings, metrics = request.app.state.settings, request.app.state.metrics
    path = settings.uploads_dir / f"{up.id}.bin"
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    rec = db.get(Recording, up.recording_id)
    if h.hexdigest() != up.sha256:
        up.status, up.error = "failed", "sha256 mismatch after assembly"
        path.unlink(missing_ok=True)
        log_event(db, up.owner_id, "upload_failed", up.error, up.recording_id)
        metrics.uploads.labels("integrity_failed").inc()
        return
    up.status = "complete"
    part = db.get(RecordingPart, up.part_id)
    part.status, part.upload_id = "uploaded", up.id
    rec.status = "queued"
    rec.change_seq = next_change_seq(db, rec.owner_id)
    job = request.app.state.pipeline.enqueue(db, up)
    request.state.job_id = job.id
    log_event(db, up.owner_id, "upload_completed", f"part {part.part_index} ({up.length} bytes)", up.recording_id)
    metrics.uploads.labels("completed").inc()


@router.delete("/{upload_id}", status_code=204)
def terminate_upload(
    upload_id: str, request: Request, who: Principal = Depends(current_principal), db: Session = Depends(get_db)
) -> Response:
    up = _get_owned(db, upload_id, who)
    if up.status == "in_progress":
        up.status, up.error = "failed", "terminated by client"
        (request.app.state.settings.uploads_dir / f"{up.id}.bin").unlink(missing_ok=True)
        db.commit()
    return Response(status_code=204, headers=_tus_headers())
