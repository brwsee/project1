import 'dart:async';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_constants.dart';
import '../../core/security/encryption_service.dart';
import '../../core/sync/hlc_clock.dart';
import '../../domain/models/knowledge_entry.dart';
import '../stt/on_device_draft_stt_service.dart';

/// حالة جلسة التسجيل الحالية (مقيدة بحد أقصى دقيقتين = 120 ثانية)
class RecordingSessionState {
  final bool isRecording;
  final bool isPaused;
  final int elapsedSeconds;
  final double currentAmplitudeDb;
  final String? activeFilePath;
  final List<int> bookmarkTimestampsMs;

  const RecordingSessionState({
    this.isRecording = false,
    this.isPaused = false,
    this.elapsedSeconds = 0,
    this.currentAmplitudeDb = -60.0,
    this.activeFilePath,
    this.bookmarkTimestampsMs = const [],
  });

  /// الوقت المتبقي بالثواني من أصل 120 ثانية
  int get remainingSeconds =>
      (AppConstants.maxRecordingDurationSeconds - elapsedSeconds)
          .clamp(0, AppConstants.maxRecordingDurationSeconds);

  /// هل دخل التسجيل في منطقة التنبيه (آخر 15 ثانية)؟
  bool get isNearLimit =>
      elapsedSeconds >= AppConstants.warningThresholdSeconds;

  /// نسبة التقدم من 0.0 إلى 1.0
  double get progress =>
      (elapsedSeconds / AppConstants.maxRecordingDurationSeconds)
          .clamp(0.0, 1.0);

  String get formattedElapsed {
    final m = (elapsedSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (elapsedSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String get formattedRemaining {
    final m = (remainingSeconds ~/ 60).toString().padLeft(2, '0');
    final s = (remainingSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  RecordingSessionState copyWith({
    bool? isRecording,
    bool? isPaused,
    int? elapsedSeconds,
    double? currentAmplitudeDb,
    String? activeFilePath,
    List<int>? bookmarkTimestampsMs,
  }) {
    return RecordingSessionState(
      isRecording: isRecording ?? this.isRecording,
      isPaused: isPaused ?? this.isPaused,
      elapsedSeconds: elapsedSeconds ?? this.elapsedSeconds,
      currentAmplitudeDb: currentAmplitudeDb ?? this.currentAmplitudeDb,
      activeFilePath: activeFilePath ?? this.activeFilePath,
      bookmarkTimestampsMs: bookmarkTimestampsMs ?? this.bookmarkTimestampsMs,
    );
  }
}

/// خدمة التسجيل الصوتي الفوري مع ميزة الاستئناف والإيقاف التلقائي عند دقيقتين (120 ثانية)
class AudioRecorderService {
  final AudioRecorder _recorder = AudioRecorder();
  final LocalEncryptionService _encryptionService;
  final HybridLogicalClock _hlcClock;
  final _uuid = const Uuid();

  Timer? _timer;
  StreamSubscription<Amplitude>? _amplitudeSub;
  final _stateController =
      StreamController<RecordingSessionState>.broadcast();

  RecordingSessionState _state = const RecordingSessionState();
  RecordingSessionState get currentState => _state;
  Stream<RecordingSessionState> get stateStream => _stateController.stream;

  /// استدعاء تلقائي عند الوصول للحد الأقصى (120 ثانية) لحفظ التسجيل فوراً
  final Future<void> Function(KnowledgeEntry autoSavedEntry)?
      onMaxDurationReached;

  AudioRecorderService({
    required LocalEncryptionService encryptionService,
    required HybridLogicalClock hlcClock,
    this.onMaxDurationReached,
  })  : _encryptionService = encryptionService,
        _hlcClock = hlcClock;

  /// بدء تسجيل جديد بصيغة Opus (أو WAV) بتردد 16kHz Mono
  Future<void> startRecording({bool useWav = false}) async {
    if (!await _recorder.hasPermission()) {
      throw StateError('لم يتم منح صلاحية الميكروفون للتطبيق.');
    }

    final docsDir = await getApplicationDocumentsDirectory();
    final recordingsDir = Directory(p.join(docsDir.path, 'recordings'));
    if (!await recordingsDir.exists()) {
      await recordingsDir.create(recursive: true);
    }

    final ext = useWav ? 'wav' : 'opus';
    final rawFilePath = p.join(
      recordingsDir.path,
      'rec_${DateTime.now().millisecondsSinceEpoch}.$ext',
    );

    final config = RecordConfig(
      encoder: useWav ? AudioEncoder.wav : AudioEncoder.opus,
      sampleRate: AppConstants.audioSampleRate,
      bitRate: AppConstants.opusBitRate,
      numChannels: AppConstants.audioChannels,
    );

    await _recorder.start(config, path: rawFilePath);

    _updateState(
      RecordingSessionState(
        isRecording: true,
        isPaused: false,
        elapsedSeconds: 0,
        activeFilePath: rawFilePath,
      ),
    );

    _startTimers();
  }

  /// إيقاف مؤقت للتسجيل
  Future<void> pauseRecording() async {
    if (!_state.isRecording || _state.isPaused) return;
    await _recorder.pause();
    _timer?.cancel();
    _updateState(_state.copyWith(isPaused: true));
  }

  /// استئناف التسجيل من حيث توقف
  Future<void> resumeRecording() async {
    if (!_state.isRecording || !_state.isPaused) return;
    await _recorder.resume();
    _updateState(_state.copyWith(isPaused: false));
    _startTimers();
  }

  /// إضافة علامة مرجعية زمنية (Bookmark Flag) أثناء التحدث لتقسيم الفقرات محلياً
  void addBookmarkFlag() {
    if (!_state.isRecording) return;
    final currentMs = _state.elapsedSeconds * 1000;
    final updatedBookmarks = <int>[..._state.bookmarkTimestampsMs, currentMs];
    _updateState(_state.copyWith(bookmarkTimestampsMs: updatedBookmarks));
  }

  /// إيقاف التسجيل، تشفيره محلياً بـ AES-256-GCM، وإنشاء كيان معرفي جاهز للحفظ
  Future<KnowledgeEntry?> stopAndFinalize({
    String? customTitle,
    ArabicDialect dialect = ArabicDialect.auto,
    String? placeName,
    double? latitude,
    double? longitude,
    String? quickKeywordsNote,
    OnDeviceDraftSttService? draftSttService,
  }) async {
    if (!_state.isRecording) return null;

    _timer?.cancel();
    await _amplitudeSub?.cancel();

    final recordedPath = await _recorder.stop();
    final durationMs = (_state.elapsedSeconds * 1000).clamp(
      1000,
      AppConstants.maxRecordingDurationSeconds * 1000,
    );
    final bookmarks = List<int>.from(_state.bookmarkTimestampsMs);

    _updateState(const RecordingSessionState());

    if (recordedPath == null) return null;
    final rawFile = File(recordedPath);
    if (!await rawFile.exists()) return null;

    // تشفير الملف الصوتي محلياً في الذاكرة (< 15ms لمقطع دقيقتين)
    final encryptedMeta = await _encryptionService.encryptAudioFile(
      rawFile,
      deleteOriginal: true,
    );

    final now = DateTime.now();
    final entryId = _uuid.v4();
    final hlc = _hlcClock.now();
    final format = recordedPath.endsWith('.wav') ? 'wav' : 'opus';

    // توليد فقرات زمنية مبدئية محلياً (On-Device Draft Segments) قابلة للبحث قبل الاتصال بالسحابة
    final initialSegments = draftSttService != null
        ? draftSttService.generateOfflineDraftSegments(
            entryId: entryId,
            durationMs: durationMs,
            dialect: dialect,
            bookmarkTimestampsMs: bookmarks,
            quickKeywordsNote: quickKeywordsNote,
          )
        : [
            TranscriptSegment(
              id: _uuid.v4(),
              entryId: entryId,
              segmentIndex: 0,
              startMs: 0,
              endMs: durationMs,
              rawText: 'بانتظار الاتصال بالإنترنت لبدء التفريغ العربي الذكي...',
              editedText:
                  'بانتظار الاتصال بالإنترنت لبدء التفريغ العربي الذكي...',
              hlcTimestamp: hlc,
            ),
          ];

    return KnowledgeEntry(
      id: entryId,
      title: (customTitle != null && customTitle.trim().isNotEmpty)
          ? customTitle.trim()
          : 'ملاحظة صوتية - ${now.year}/${now.month}/${now.day} ${now.hour}:${now.minute.toString().padLeft(2, '0')}',
      recordedAt: now,
      durationMs: durationMs,
      audioFormat: format,
      sampleRate: AppConstants.audioSampleRate,
      localFilePath: encryptedMeta.encryptedFilePath,
      fileSizeBytes: encryptedMeta.sizeBytes,
      fileSha256: encryptedMeta.sha256Hex,
      encryptionIv: encryptedMeta.ivBase64,
      latitude: latitude,
      longitude: longitude,
      placeName: (placeName != null && placeName.trim().isNotEmpty)
          ? placeName.trim()
          : null,
      dialectHint: dialect,
      syncStatus: SyncStatus.localOnly,
      hlcTimestamp: hlc,
      createdAt: now,
      updatedAt: now,
      segments: initialSegments,
    );
  }

  void _startTimers() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) async {
      final nextSeconds = _state.elapsedSeconds + 1;

      if (nextSeconds >= AppConstants.maxRecordingDurationSeconds) {
        // وصل المقطع إلى الحد الأقصى (دقيقتان = 120 ثانية) -> إيقاف وحفظ تلقائي آمن
        timer.cancel();
        final entry = await stopAndFinalize(
          customTitle: 'ملاحظة صوتية مكتملة (دقيقتان)',
        );
        if (entry != null && onMaxDurationReached != null) {
          await onMaxDurationReached!(entry);
        }
      } else {
        _updateState(_state.copyWith(elapsedSeconds: nextSeconds));
      }
    });

    _amplitudeSub?.cancel();
    _amplitudeSub = _recorder
        .onAmplitudeChanged(const Duration(milliseconds: 120))
        .listen((amp) {
      if (_state.isRecording && !_state.isPaused) {
        _updateState(_state.copyWith(currentAmplitudeDb: amp.current));
      }
    });
  }

  void _updateState(RecordingSessionState newState) {
    _state = newState;
    if (!_stateController.isClosed) {
      _stateController.add(newState);
    }
  }

  Future<void> dispose() async {
    _timer?.cancel();
    await _amplitudeSub?.cancel();
    await _recorder.dispose();
    await _stateController.close();
  }
}
