import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/benchmark/golden_arabic_dataset.dart';
import '../../core/logging/app_logger_service.dart';
import '../../core/utils/arabic_text_evaluator.dart';
import '../../domain/models/knowledge_entry.dart';
import '../../main.dart';
import '../../services/storage/storage_quota_service.dart';

/// شاشة الإعدادات المتقدمة:
/// 1. حدود التخزين المحلي والإخلاء الذكي
/// 2. سجل التحميلات والفشل وملفات اللوج
/// 3. مختبر اختبار دقة التفريغ العربي (Arabic WER Benchmark)
/// 4. سياسة الخصوصية والتشفير المحلي
class SettingsAndDiagnosticsScreen extends ConsumerStatefulWidget {
  const SettingsAndDiagnosticsScreen({super.key});

  @override
  ConsumerState<SettingsAndDiagnosticsScreen> createState() =>
      _SettingsAndDiagnosticsScreenState();
}

class _SettingsAndDiagnosticsScreenState
    extends ConsumerState<SettingsAndDiagnosticsScreen> {
  StorageUsageSummary? _storageSummary;
  List<UploadQueueItem> _uploadQueue = [];
  List<AppLogEvent> _logs = [];
  double _quotaMb = 500;

  // حقول مختبر قياس دقة التفريغ العربي
  final _refController = TextEditingController(
    text: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ، هَذِهِ خُلَاصَةٌ مَعْرِفِيَّةٌ مُسَجَّلَةٌ عَبْرَ المَكْتَبَةِ المَعْرِفِيَّةِ الذَّكِيَّةِ.',
  );
  final _hypController = TextEditingController(
    text: 'بسم الله الرحمن الرحيم هذه خلاصه معرفيه مسجله عبر المكتبه المعرفيه الذكيه',
  );

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  @override
  void dispose() {
    _refController.dispose();
    _hypController.dispose();
    super.dispose();
  }

  Future<void> _refreshData() async {
    final storageService = ref.read(storageQuotaServiceProvider);
    final db = ref.read(localDatabaseProvider);
    final logger = ref.read(appLoggerProvider);

    final summary = await storageService.calculateUsage();
    final queue = await db.getAllUploadQueueItems();
    final logs = await logger.loadLogsFromDisk(limit: 50);

    if (mounted) {
      setState(() {
        _storageSummary = summary;
        _quotaMb = (summary.maxAllowedBytes / (1024 * 1024)).clamp(50, 2000);
        _uploadQueue = queue;
        _logs = logs;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final summary = _storageSummary;
    final accuracy = ArabicTextEvaluator.calculateAccuracyPercentage(
      _refController.text,
      _hypController.text,
    );
    final wer = ArabicTextEvaluator.calculateNormalizedWer(
      _refController.text,
      _hypController.text,
    );

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الإعدادات، السجلات، وجودة التفريغ'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(icon: Icon(Icons.storage), text: 'التخزين'),
              Tab(icon: Icon(Icons.cloud_upload), text: 'سجل التحميلات واللوج'),
              Tab(icon: Icon(Icons.analytics), text: 'اختبار دقة العربية'),
              Tab(icon: Icon(Icons.security), text: 'الخصوصية والأمان'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // 1. تبويب حدود التخزين المحلي والإخلاء الذكي
            ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'استهلاك التخزين الصوتي المشفر محلياً',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 12),
                        LinearProgressIndicator(
                          value: summary?.usageRatio ?? 0.0,
                          minHeight: 10,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'المستخدم حالياً: ${summary?.formattedUsedMb ?? "0.00"} MB من أصل ${_quotaMb.toStringAsFixed(0)} MB',
                        ),
                        Text(
                          'إجمالي الكيانات المعرفية: ${summary?.totalEntriesCount ?? 0} (منها ${summary?.localAudioFilesCount ?? 0} بملف صوتي محلي)',
                        ),
                        const Divider(height: 24),
                        Text(
                          'تحديد الحد الأقصى للتخزين الصوتي (${_quotaMb.toStringAsFixed(0)} MB):',
                        ),
                        Slider(
                          value: _quotaMb,
                          min: 50,
                          max: 2000,
                          divisions: 39,
                          label: '${_quotaMb.toStringAsFixed(0)} MB',
                          onChanged: (val) {
                            setState(() => _quotaMb = val);
                            ref
                                .read(storageQuotaServiceProvider)
                                .setMaxAllowedBytes(
                                  (val * 1024 * 1024).toInt(),
                                );
                          },
                        ),
                        const SizedBox(height: 8),
                        FilledButton.tonalIcon(
                          onPressed: () async {
                            final freed = await ref
                                .read(storageQuotaServiceProvider)
                                .enforceQuotaOrEvictSyncedAudio(
                                  forceEvictAllSynced: true,
                                );
                            await _refreshData();
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    'تم إخلاء ${(freed / 1024).toStringAsFixed(1)} KB من الملفات الصوتية المتزامنة مع بقاء النصوص كاملة.',
                                  ),
                                ),
                              );
                            }
                          },
                          icon: const Icon(Icons.cleaning_services_outlined),
                          label: Text(
                            'إخلاء ذكي للمساحة المتزامنة (${summary?.formattedEvictableMb ?? "0.00"} MB متاحة للإخلاء)',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // 2. تبويب سجل التحميلات والفشل وملفات اللوج
            ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'طابور الرفع القابل للاستئناف (TUS Queue)',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    TextButton.icon(
                      onPressed: _refreshData,
                      icon: const Icon(Icons.refresh, size: 18),
                      label: const Text('تحديث'),
                    ),
                  ],
                ),
                if (_uploadQueue.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'لا توجد عمليات رفع معلقة أو فاشلة حالياً. جميع التسجيلات مرفوعة بسلام.',
                      ),
                    ),
                  )
                else
                  ..._uploadQueue.map(
                    (item) => Card(
                      child: ListTile(
                        leading: const Icon(Icons.cloud_Queue),
                        title: Text('معرّف التسجيل: ${item.entryId.substring(0, 8)}...'),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            LinearProgressIndicator(value: item.progress),
                            const SizedBox(height: 4),
                            Text(
                              'تم رفع ${item.bytesUploaded} من ${item.totalBytes} بايت | المحاولات: ${item.retryCount}',
                            ),
                            if (item.lastErrorMessage != null)
                              Text(
                                'سبب الفشل الأخير: ${item.lastErrorMessage}',
                                style: const TextStyle(color: Colors.red),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'سجل الأحداث ومؤشرات الأداء (Telemetry Logs)',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    TextButton(
                      onPressed: () async {
                        await ref.read(appLoggerProvider).clearLogs();
                        await _refreshData();
                      },
                      child: const Text('مسح السجل'),
                    ),
                  ],
                ),
                if (_logs.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('لا توجد سجلات تشخيصية بعد.'),
                    ),
                  )
                else
                  ..._logs.map(
                    (log) => Card(
                      child: ListTile(
                        dense: true,
                        leading: Icon(
                          log.level == LogLevel.error
                              ? Icons.error_outline
                              : Icons.info_outline,
                          color: log.level == LogLevel.error
                              ? Colors.red
                              : Colors.teal,
                        ),
                        title: Text('[${log.category}] ${log.message}'),
                        subtitle: Text(log.timestamp.toIso8601String()),
                      ),
                    ),
                  ),
              ],
            ),

            // 3. تبويب اختبار دقة التفريغ العربي (Normalized Arabic WER + Golden Dataset)
            ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'مختبر فحص دقة التفريغ العربي (Arabic STT Benchmark)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                const Text(
                  'يقيس هذا المختبر الدقة الفعلية بعد تطبيع قواعد الإملاء العربية (توحيد الهمزات، التاء المربوطة عند الوقف، وإزالة التشكيل).',
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _refController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'النص المرجعي الصحيح (Reference Transcript)',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _hypController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'النص الناتج من محرك التفريغ (Hypothesis STT)',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 16),
                Card(
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Text(
                          'دقة التفريغ العربي: ${accuracy.toStringAsFixed(1)}%',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'معدل خطأ الكلمات المطبّع (Normalized WER): ${(wer * 100).toStringAsFixed(2)}%',
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(height: 32),
                const Text(
                  'حزمة الاختبار المرجعية للهجات العربية (Golden Arabic Dialect Suite)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                ...GoldenArabicBenchmarkSuite.standardCases.map(
                  (bench) => Card(
                    child: ListTile(
                      leading: Icon(
                        bench.isPassed ? Icons.verified : Icons.warning_amber,
                        color: bench.isPassed ? Colors.green : Colors.orange,
                      ),
                      title: Text(bench.environmentDescription),
                      subtitle: Text(
                        'النص المرجعي: ${bench.referenceTranscript}\n'
                        'الدقة المقاسة: ${bench.measuredAccuracyPercent.toStringAsFixed(1)}% (الحد الأدنى المطلوب: ${bench.targetMinAccuracyPercent}%)',
                      ),
                      onTap: () {
                        setState(() {
                          _refController.text = bench.referenceTranscript;
                          _hypController.text = bench.simulatedSttOutput;
                        });
                      },
                    ),
                  ),
                ),
              ],
            ),

            // 4. تبويب سياسة الخصوصية والتشفير
            ListView(
              padding: const EdgeInsets.all(16),
              children: const [
                Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'سياسة الخصوصية والأمان في «المكتبة المعرفية الذكية»',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 12),
                        Text(
                          '1. التشفير المحلي الشامل (Local-First Encryption):\n'
                          'تُشفر جميع المقاطع الصوتية (الحد الأقصى دقيقتان للمقطع) فور انتهاء التسجيل على جهازك باستخدام خوارزمية AES-256-GCM قبل كتابتها الدائمة، وتُحفظ مفاتيح التشفير داخل شريحة الأمان (Android Keystore / iOS Secure Enclave).',
                        ),
                        SizedBox(height: 10),
                        Text(
                          '2. قاعدة البيانات المشفرة:\n'
                          'تُحفظ النصوص المفرّغة، الطوابع الزمنية، والبيانات الوصفية داخل قاعدة بيانات SQLCipher مشفرة محلياً.',
                        ),
                        SizedBox(height: 10),
                        Text(
                          '3. النقل السحابي والتفريغ الآمن:\n'
                          'يتم رفع المقاطع الصوتية عبر اتصال HTTPS مشفر ببروتوكول TUS القابل للاستئناف لغرض التفريغ النصي العربي فقط، ولا يُستخدم محتواك الصوتي لتدريب أي نماذج خارجية دون موافقة صريحة.',
                        ),
                        SizedBox(height: 10),
                        Text(
                          '4. بيانات الموقع الجغرافي الاختيارية:\n'
                          'لا يلتقط التطبيق موقعك الجغرافي إلا عند تفعيلك الاختياري له لتوثيق مكان الملاحظة المعرفية، ويمكنك حذف أي تسجيل ونسخته السحابية نهائياً في أي وقت.',
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
