import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// مستويات اللوج التطبيقي
enum LogLevel { info, warning, error }

/// سجل حدث واحد (لأغراض مراقبة الأداء وتشخيص الرفع والتفريغ)
class AppLogEvent {
  final DateTime timestamp;
  final LogLevel level;
  final String category; // 'AUDIO', 'UPLOAD_TUS', 'ARABIC_STT', 'STORAGE', 'SYNC_HLC'
  final String message;
  final Map<String, dynamic>? metrics;

  const AppLogEvent({
    required this.timestamp,
    required this.level,
    required this.category,
    required this.message,
    this.metrics,
  });

  Map<String, dynamic> toJson() => {
        'ts': timestamp.toIso8601String(),
        'level': level.name.toUpperCase(),
        'cat': category,
        'msg': message,
        if (metrics != null) 'metrics': metrics,
      };

  factory AppLogEvent.fromJson(Map<String, dynamic> json) {
    return AppLogEvent(
      timestamp: DateTime.tryParse(json['ts'] as String? ?? '') ?? DateTime.now(),
      level: LogLevel.values.firstWhere(
        (e) => e.name.toUpperCase() == (json['level'] as String? ?? 'INFO'),
        orElse: () => LogLevel.info,
      ),
      category: json['cat'] as String? ?? 'GENERAL',
      message: json['msg'] as String? ?? '',
      metrics: json['metrics'] as Map<String, dynamic>?,
    );
  }
}

/// خدمة تسجيل الأحداث ومؤشرات الأداء (Rotating JSONL Logger - بحد أقصى 5MB)
class AppLoggerService {
  static const _logFileName = 'skl_telemetry_logs.jsonl';
  static const _maxLogSizeBytes = 5 * 1024 * 1024; // 5 MB

  final List<AppLogEvent> _recentMemoryLogs = [];
  List<AppLogEvent> get recentLogs => List.unmodifiable(_recentMemoryLogs.reversed);

  Future<File> _getLogFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File(p.join(dir.path, _logFileName));
  }

  Future<void> log({
    required String category,
    required String message,
    LogLevel level = LogLevel.info,
    Map<String, dynamic>? metrics,
  }) async {
    final event = AppLogEvent(
      timestamp: DateTime.now(),
      level: level,
      category: category,
      message: message,
      metrics: metrics,
    );

    _recentMemoryLogs.add(event);
    if (_recentMemoryLogs.length > 200) {
      _recentMemoryLogs.removeAt(0);
    }

    try {
      final file = await _getLogFile();
      if (await file.exists() && await file.length() > _maxLogSizeBytes) {
        // تدوير ملف اللوج عند تجاوز الحد الأقصى
        final backupFile = File('${file.path}.old');
        if (await backupFile.exists()) await backupFile.delete();
        await file.rename(backupFile.path);
      }

      await file.writeAsString(
        '${jsonEncode(event.toJson())}\n',
        mode: FileMode.append,
        flush: true,
      );
    } catch (_) {
      // ضمان عدم تعطل التطبيق في حال فشل الكتابة للقرص
    }
  }

  /// قراءة آخر السجلات من القرص لعرضها في شاشة التشخيص
  Future<List<AppLogEvent>> loadLogsFromDisk({int limit = 100}) async {
    try {
      final file = await _getLogFile();
      if (!await file.exists()) return recentLogs;
      final lines = await file.readAsLines();
      final events = <AppLogEvent>[];
      for (final line in lines.reversed.take(limit)) {
        if (line.trim().isEmpty) continue;
        events.add(
          AppLogEvent.fromJson(jsonDecode(line) as Map<String, dynamic>),
        );
      }
      return events;
    } catch (_) {
      return recentLogs;
    }
  }

  Future<void> clearLogs() async {
    _recentMemoryLogs.clear();
    final file = await _getLogFile();
    if (await file.exists()) {
      await file.delete();
    }
  }
}
