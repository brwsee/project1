from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class DevTokenIn(BaseModel):
    user_id: str = Field(min_length=1, max_length=64)
    device_id: str = Field(min_length=1, max_length=64)


class PartIn(BaseModel):
    id: str = Field(min_length=36, max_length=36)
    part_index: int = Field(ge=0)
    duration_ms: int = Field(ge=0)


class RecordingUpsert(BaseModel):
    id: str = Field(min_length=36, max_length=36)
    title: str = Field(default="", max_length=300)
    recorded_at: datetime
    duration_ms: int = Field(ge=0)
    codec: str = Field(pattern="^(wav|opus|aac|flac)$")
    sample_rate: int = Field(ge=8000, le=96000)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    place_name: str | None = Field(default=None, max_length=200)
    dialect_hint: str | None = Field(default=None, max_length=16)
    parts: list[PartIn] = Field(default_factory=list)


class SegmentOut(BaseModel):
    seg_uid: str
    idx: int
    start_ms: int
    end_ms: int
    speaker: str | None
    text: str
    original_text: str
    edited: bool


class SegmentEdit(BaseModel):
    seg_uid: str
    text: str = Field(max_length=20_000)


class TranscriptEdit(BaseModel):
    base_version: int
    title: str | None = Field(default=None, max_length=300)
    segments: list[SegmentEdit]


class RecordingOut(BaseModel):
    id: str
    title: str
    recorded_at: datetime
    duration_ms: int
    codec: str
    latitude: float | None
    longitude: float | None
    place_name: str | None
    dialect_hint: str | None
    status: str
    version: int
    change_seq: int
    deleted: bool
    formatted_text: str | None
    last_editor_device: str | None
    segments: list[SegmentOut] = Field(default_factory=list)


class ChangesOut(BaseModel):
    cursor: int
    has_more: bool
    recordings: list[RecordingOut]


class EventOut(BaseModel):
    id: int
    recording_id: str | None
    kind: str
    message: str
    at: datetime
