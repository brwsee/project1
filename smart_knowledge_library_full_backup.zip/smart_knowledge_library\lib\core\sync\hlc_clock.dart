/// تطبيق للساعة المنطقية الهجينة (Hybrid Logical Clock - HLC)
/// يُستخدم لترتيب التعديلات وحل التعارضات بين الأجهزة المتعددة بدون إنترنت
class HybridLogicalClock {
  final String nodeId;
  int _lastPhysicalMs = 0;
  int _logicalCounter = 0;

  HybridLogicalClock({required this.nodeId});

  /// توليد طابع HLC جديد عند حدوث تعديل محلي
  /// الصيغة: `<physical_time_iso>-<counter_hex>-<nodeId>`
  String now() {
    final currentPhysicalMs = DateTime.now().toUtc().millisecondsSinceEpoch;
    if (currentPhysicalMs > _lastPhysicalMs) {
      _lastPhysicalMs = currentPhysicalMs;
      _logicalCounter = 0;
    } else {
      _logicalCounter++;
    }
    return _format(_lastPhysicalMs, _logicalCounter, nodeId);
  }

  /// تحديث الساعة المحلية عند استقبال طابع HLC من السحابة أو جهاز آخر
  String receive(String remoteHlc) {
    final parsed = parse(remoteHlc);
    final currentPhysicalMs = DateTime.now().toUtc().millisecondsSinceEpoch;

    if (currentPhysicalMs > _lastPhysicalMs &&
        currentPhysicalMs > parsed.physicalMs) {
      _lastPhysicalMs = currentPhysicalMs;
      _logicalCounter = 0;
    } else if (_lastPhysicalMs == parsed.physicalMs) {
      _logicalCounter =
          (_logicalCounter > parsed.counter ? _logicalCounter : parsed.counter) +
              1;
    } else if (parsed.physicalMs > _lastPhysicalMs) {
      _lastPhysicalMs = parsed.physicalMs;
      _logicalCounter = parsed.counter + 1;
    } else {
      _logicalCounter++;
    }

    return _format(_lastPhysicalMs, _logicalCounter, nodeId);
  }

  static String _format(int physicalMs, int counter, String node) {
    final ts = physicalMs.toRadixString(16).padLeft(12, '0');
    final cnt = counter.toRadixString(16).padLeft(4, '0');
    return '$ts-$cnt-$node';
  }

  static ({int physicalMs, int counter, String nodeId}) parse(String hlc) {
    final parts = hlc.split('-');
    if (parts.length < 3) {
      return (physicalMs: 0, counter: 0, nodeId: 'unknown');
    }
    return (
      physicalMs: int.tryParse(parts[0], radix: 16) ?? 0,
      counter: int.tryParse(parts[1], radix: 16) ?? 0,
      nodeId: parts.sublist(2).join('-'),
    );
  }
}
