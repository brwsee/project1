import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:uuid/uuid.dart';
import '../../core/constants/app_constants.dart';
import '../../core/sync/hlc_clock.dart';
import '../../data/local/local_database.dart';
import '../../domain/models/knowledge_entry.dart';

/// خدمة الرفع الموثوق (TUS Resumable Upload) وطلب التفريغ النصي العربي
/// مصممة خصيصاً للمقاطع القصيرة (≤ دقيقتين) بحيث ترفع في جزء واحد أو جزأين (256KB)
class SyncUploadService {
  final LocalDatabase _localDb;
  final HybridLogicalClock _hlcClock;
  final Dio _dio;
  final String _baseUrl;
  final _uuid = const Uuid();

  /// وضع المحاكاة المحلي للتجربة الفورية بدون خادم خلفي نشط
  final bool simulateCloudInDemoMode;

  SyncUploadService({
    required LocalDatabase localDb,
    required HybridLogicalClock hlcClock,
    Dio? dio,
    String baseUrl = 'https://api.smart-knowledge-lib.example.com/v1',
    this.simulateCloudInDemoMode = true,
  })  : _localDb = localDb,
        _hlcClock = hlcClock,
        _baseUrl = baseUrl,
        _dio = dio ??
            Dio(
              BaseOptions(
                connectTimeout: const Duration(seconds: 15),
                receiveTimeout: const Duration(seconds: 30),
              ),
            );

  /// تشغيل دورة مزامنة شاملة لكل التسجيلات المحلية المعلقة
  Future<int> syncPendingEntries() async {
    final pendingQueue = await _localDb.getPendingUploads();
    var successCount = 0;

    for (final item in pendingQueue) {
      final entry = await _localDb.getEntryById(item.entryId);
      if (entry == null || entry.localFilePath == null) continue;

      final encryptedFile = File(entry.localFilePath!);
      if (!await encryptedFile.exists()) continue;

      try {
        // 1. تحديث الحالة إلى: جارٍ الرفع
        await _localDb.updateUploadProgress(item, SyncStatus.uploading);

        if (simulateCloudInDemoMode) {
          await _simulateUploadAndArabicStt(entry, item);
          successCount++;
          continue;
        }

        // 2. إنشاء جلسة TUS أو استئناف الجلسة السابقة
        final uploadUrl = item.tusUploadUrl ??
            await _createTusSession(entry, encryptedFile.lengthSync());

        // 3. الاستعلام عن الـ Offset الحالي على الخادم
        final serverOffset = await _getServerOffset(uploadUrl);

        // 4. رفع الأجزاء المتبقية (256 KB لكل جزء - مقطع دقيقتين Opus يحتاج جزأين فقط)
        await _uploadRemainingChunks(
          entry: entry,
          queueItem: item,
          encryptedFile: encryptedFile,
          uploadUrl: uploadUrl,
          startOffset: serverOffset,
        );

        // 5. طلب التفريغ العربي الدقيق (Whisper Large-v3 / Gemini Audio + التدقيق النحوي)
        await _localDb.updateUploadProgress(
          UploadQueueItem(
            entryId: entry.id,
            tusUploadUrl: uploadUrl,
            bytesUploaded: entry.fileSizeBytes,
            totalBytes: entry.fileSizeBytes,
            updatedAt: DateTime.now(),
          ),
          SyncStatus.processing,
        );

        final cloudSegments = await _requestArabicTranscription(entry);
        final remoteHlc = _hlcClock.now();

        // 6. دمج التفريغ مع الحفاظ على تعديلات المستخدم المحلية
        await _localDb.mergeCloudTranscript(
          entryId: entry.id,
          cloudSegments: cloudSegments,
          remoteHlc: remoteHlc,
        );

        successCount++;
      } catch (e) {
        // جدولة إعادة المحاولة (Exponential Backoff) وتسجيل الخطأ في السجل
        final nextRetryCount = item.retryCount + 1;
        final backoffSeconds = (1 << nextRetryCount.clamp(1, 6)) * 5;
        final failedItem = UploadQueueItem(
          entryId: item.entryId,
          tusUploadUrl: item.tusUploadUrl,
          bytesUploaded: item.bytesUploaded,
          totalBytes: item.totalBytes,
          retryCount: nextRetryCount,
          nextRetryAt: DateTime.now().add(Duration(seconds: backoffSeconds)),
          lastErrorCode: 'UPLOAD_OR_STT_ERROR',
          lastErrorMessage: e.toString(),
          updatedAt: DateTime.now(),
        );
        await _localDb.updateUploadProgress(failedItem, SyncStatus.failed);
      }
    }

    return successCount;
  }

  Future<String> _createTusSession(
    KnowledgeEntry entry,
    int totalBytes,
  ) async {
    final metadata = {
      'entryId': base64Encode(utf8.encode(entry.id)),
      'sha256': base64Encode(utf8.encode(entry.fileSha256)),
      'iv': base64Encode(utf8.encode(entry.encryptionIv)),
      'dialect': base64Encode(utf8.encode(entry.dialectHint.code)),
    };
    final headerMeta =
        metadata.entries.map((e) => '${e.key} ${e.value}').join(',');

    final response = await _dio.post<void>(
      '$_baseUrl/uploads/tus',
      options: Options(
        headers: {
          'Tus-Resumable': '1.0.0',
          'Upload-Length': totalBytes.toString(),
          'Upload-Metadata': headerMeta,
        },
      ),
    );

    final location = response.headers.value('location');
    if (location == null || location.isEmpty) {
      throw StateError('لم يُرجع الخادم رابط جلسة الرفع TUS Location.');
    }
    return location;
  }

  Future<int> _getServerOffset(String uploadUrl) async {
    final response = await _dio.head<void>(
      uploadUrl,
      options: Options(headers: {'Tus-Resumable': '1.0.0'}),
    );
    final offsetStr = response.headers.value('upload-offset');
    return int.tryParse(offsetStr ?? '0') ?? 0;
  }

  Future<void> _uploadRemainingChunks({
    required KnowledgeEntry entry,
    required UploadQueueItem queueItem,
    required File encryptedFile,
    required String uploadUrl,
    required int startOffset,
  }) async {
    final raf = await encryptedFile.open(mode: FileMode.read);
    try {
      var offset = startOffset;
      final total = await encryptedFile.length();

      while (offset < total) {
        await raf.setPosition(offset);
        final chunkBytes =
            await raf.read(AppConstants.uploadChunkSizeBytes);

        final response = await _dio.patch<void>(
          uploadUrl,
          data: Stream.fromIterable([chunkBytes]),
          options: Options(
            headers: {
              'Tus-Resumable': '1.0.0',
              'Upload-Offset': offset.toString(),
              'Content-Type': 'application/offset+octet-stream',
              'Content-Length': chunkBytes.length.toString(),
            },
          ),
        );

        final newOffsetStr = response.headers.value('upload-offset');
        offset = int.tryParse(newOffsetStr ?? '') ??
            (offset + chunkBytes.length);

        await _localDb.updateUploadProgress(
          UploadQueueItem(
            entryId: entry.id,
            tusUploadUrl: uploadUrl,
            bytesUploaded: offset,
            totalBytes: total,
            updatedAt: DateTime.now(),
          ),
          SyncStatus.uploading,
        );
      }
    } finally {
      await raf.close();
    }
  }

  Future<List<TranscriptSegment>> _requestArabicTranscription(
    KnowledgeEntry entry,
  ) async {
    final response = await _dio.post<Map<String, dynamic>>(
      '$_baseUrl/entries/${entry.id}/transcribe',
      data: {
        'dialect_hint': entry.dialectHint.code,
        'max_duration_sec': AppConstants.maxRecordingDurationSeconds,
        'enable_grammar_punctuation': true,
      },
    );

    final data = response.data ?? {};
    final rawSegments = (data['segments'] as List<dynamic>? ?? []);
    final hlc = _hlcClock.now();

    return rawSegments.asMap().entries.map((item) {
      final idx = item.key;
      final map = item.value as Map<String, dynamic>;
      return TranscriptSegment(
        id: _uuid.v4(),
        entryId: entry.id,
        segmentIndex: idx,
        startMs: map['start_ms'] as int? ?? 0,
        endMs: map['end_ms'] as int? ?? entry.durationMs,
        rawText: map['raw_text'] as String? ?? '',
        editedText: map[' punctuated_text'] as String? ??
            map['raw_text'] as String? ??
            '',
        confidence: (map['confidence'] as num?)?.toDouble() ?? 0.96,
        hlcTimestamp: hlc,
      );
    }).toList();
  }

  /// محاكاة عملية الرفع السريع والتفريغ العربي المنسق بطوابع زمنية للتجربة المحلية
  Future<void> _simulateUploadAndArabicStt(
    KnowledgeEntry entry,
    UploadQueueItem item,
  ) async {
    await Future<void>.delayed(const Duration(milliseconds: 500));
    await _localDb.updateUploadProgress(
      UploadQueueItem(
        entryId: entry.id,
        bytesUploaded: entry.fileSizeBytes ~/ 2,
        totalBytes: entry.fileSizeBytes,
        updatedAt: DateTime.now(),
      ),
      SyncStatus.uploading,
    );

    await Future<void>.delayed(const Duration(milliseconds: 500));
    await _localDb.updateUploadProgress(
      UploadQueueItem(
        entryId: entry.id,
        bytesUploaded: entry.fileSizeBytes,
        totalBytes: entry.fileSizeBytes,
        updatedAt: DateTime.now(),
      ),
      SyncStatus.processing,
    );

    await Future<void>.delayed(const Duration(milliseconds: 700));
    final hlc = _hlcClock.now();
    final halfMs = (entry.durationMs ~/ 2).clamp(1000, 60000);

    final simulatedSegments = [
      TranscriptSegment(
        id: _uuid.v4(),
        entryId: entry.id,
        segmentIndex: 0,
        startMs: 0,
        endMs: halfMs,
        rawText:
            'بسم الله الرحمن الرحيم هذه خلاصة معرفية مسجلة عبر المكتبة المعرفية الذكية',
        editedText:
            'بسم الله الرحمن الرحيم، هذه خلاصة معرفية مسجلة عبر «المكتبة المعرفية الذكية».',
        confidence: 0.97,
        hlcTimestamp: hlc,
      ),
      TranscriptSegment(
        id: _uuid.v4(),
        entryId: entry.id,
        segmentIndex: 1,
        startMs: halfMs,
        endMs: entry.durationMs,
        rawText:
            'تم حفظ المقطع محليا وتشفيره ثم تفريغه بدقة عالية مع الفواصل الزمنية وعلامات الترقيم',
        editedText:
            'تم حفظ المقطع محلياً وتشفيره، ثم تفريغه بدقة عالية مع الفواصل الزمنية وعلامات الترقيم.',
        confidence: 0.95,
        hlcTimestamp: hlc,
      ),
    ];

    await _localDb.mergeCloudTranscript(
      entryId: entry.id,
      cloudSegments: simulatedSegments,
      remoteHlc: hlc,
    );
  }
}
